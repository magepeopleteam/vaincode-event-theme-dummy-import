<?php
/*
Plugin Name: Vaincode Theme Core
Plugin URI: https://vaincode.com
Description: The Ultimate Core Processor of the Vaincode theme - Manage your website easier with Vaincode Theme Core.
Version: 1.0
Author: Vaincode
Author URI: https://vaincode.com
Text Domain: vaincode-theme-core
Domain Path: /languages/
*/

define( 'VAINCODE_THEME_CORE_VERSION', '1.0' );
define( 'VAINCODE_THEME_CORE__FILE__', __FILE__ );
define( 'VAINCODE_THEME_CORE_DIR_URL', plugin_dir_url( VAINCODE_THEME_CORE__FILE__ ) );
define( 'VAINCODE_THEME_CORE_INC', trailingslashit( VAINCODE_THEME_CORE_DIR_URL . 'inc' ) );
define( 'VAINCODE_THEME_CORE_ASSET', trailingslashit( VAINCODE_THEME_CORE_DIR_URL . 'asset' ) );

#-----------------------------------------------------------------
# Load Vaincode Theme Option Functions
#-----------------------------------------------------------------

if ( !class_exists( 'ReduxFramework' )) {
    require_once('inc/admin/redux-core/framework.php' );
}

if ( !isset( $theme_option_data ) ) {
    require_once('inc/admin/config/config.php' );
}

#-----------------------------------------------------------------
# Load Vaincode Widget Functions
#-----------------------------------------------------------------

require_once('inc/vaincode-widgets.php' );

#-----------------------------------------------------------------
# Load Vaincode Metabox Functions
#-----------------------------------------------------------------

require_once('inc/vaincode-metabox.php' );

#-----------------------------------------------------------------
# Load Vaincode Mega-Menu Function
#-----------------------------------------------------------------

require_once('inc/vaincode-mega-menu.php' );

#-----------------------------------------------------------------
# Load Vaincode Enqueue Function
#-----------------------------------------------------------------

require_once('inc/vaincode-enqueue.php' );