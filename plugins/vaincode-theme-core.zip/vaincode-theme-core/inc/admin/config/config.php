<?php
    if ( ! class_exists( 'Redux' ) ) {
        return;
    }

	$theme_option=get_option( 'theme_option_data' );
    // This is your option name where all the Redux data is stored.
    $opt_name = "theme_option_data";
    // This line is only for altering the demo. Can be easily removed.
    $opt_name = apply_filters( 'redux_demo/opt_name', $opt_name );
    /**
     * ---> SET ARGUMENTS
     * All the possible arguments for Redux.
     * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
     * */

    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        // TYPICAL -> Change these values as you need/desire
        'opt_name'             => $opt_name,
        // This is where your data is stored in the database and also becomes your global variable name.
        'display_name'         => $theme->get( 'Name' ),
        // Name that appears at the top of your panel
        'display_version'      => $theme->get( 'Version' ),
        // Version that appears at the top of your panel
        'menu_type'            => 'submenu',
        //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
        'allow_sub_menu'       => true,
        // Show the sections below the admin menu item or not
        'menu_title'           => esc_html__( 'Theme Options', 'vaincode-theme-core' ),
        'page_title'           => esc_html__( 'Theme Options', 'vaincode-theme-core' ),
        // You will need to generate a Google API key to use this feature.
        // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
        'google_api_key'       => '',
        // Set it you want google fonts to update weekly. A google_api_key value is required.
        'google_update_weekly' => false,
        // Must be defined to add google fonts to the typography module
        'async_typography'     => false,
        // Use a asynchronous font on the front end or font string
        //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
        'admin_bar'            => false,
        // Show the panel pages on the admin bar
        'admin_bar_icon'       => 'dashicons-portfolio',
        // Choose an icon for the admin bar menu
        'admin_bar_priority'   => 50,
        // Choose an priority for the admin bar menu
        'global_variable'      => '',
        // Set a different name for your global variable other than the opt_name
        'dev_mode'             => false,
        // Show the time the page took to load, etc
        'update_notice'        => false,
        // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
        'customizer'           => false,
        // Enable basic customizer support
        //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
        //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

        // OPTIONAL -> Give you extra features
        'page_priority'        => null,
        // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
        'page_parent'          => 'vaincode-options',
        // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
        'page_permissions'     => 'manage_options',
        // Permissions needed to access the options panel.
        'menu_icon'            => '',
        // Specify a custom URL to an icon
        'last_tab'             => '',
        // Force your panel to always open to a specific tab (by id)
        'page_icon'            => 'icon-themes',
        // Icon displayed in the admin panel next to your menu_title
        'page_slug'            => 'vaincode-options-theme',
        // Page slug used to denote the panel, will be based off page title then menu title then opt_name if not provided
        'save_defaults'        => true,
        // On load save the defaults to DB before user clicks save or not
        'default_show'         => false,
        // If true, shows the default value next to each field that is not the default value.
        'default_mark'         => '',
        // What to print by the field's title if the value shown is default. Suggested: *
        'show_import_export'   => true,
        // Shows the Import/Export panel when not used as a field.

        // CAREFUL -> These options are for advanced use only
       // 'transient_time'       => 60 * MINUTE_IN_SECONDS,
        'output'               => true,
        // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
        'output_tag'           => true,
        // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
        // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

        // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
        'database'             => '',
        // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
        'use_cdn'              => true,
		'show_options_object' => false,
        // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

        // HINTS
        'hints'                => array(
            'icon'          => 'el el-question-sign',
            'icon_position' => 'right',
            'icon_color'    => 'lightgray',
            'icon_size'     => 'normal',
            'tip_style'     => array(
                'color'   => 'red',
                'shadow'  => true,
                'rounded' => false,
                'style'   => '',
            ),
            'tip_position'  => array(
                'my' => 'top left',
                'at' => 'bottom right',
            ),
            'tip_effect'    => array(
                'show' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'mouseover',
                ),
                'hide' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'click mouseleave',
                ),
            ),
        )
    );

	$allowed_html = array(
    'span' => array(),
    'a' => array('href'=> array()),
    'p' => array(),
);

    // SOCIAL ICONS -> Setup custom links in the footer for quick links in your panel footer icons.


    // Panel Intro text -> before the form
    if ( ! isset( $args['global_variable'] ) || $args['global_variable'] !== false ) {
        if ( ! empty( $args['global_variable'] ) ) {
            $v = $args['global_variable'];
        } else {
            $v = str_replace( '-', '_', $args['opt_name'] );
        }
        $args['intro_text'] = sprintf( esc_html__( '', 'vaincode-theme-core' ), $v );
    } else {
        $args['intro_text'] = esc_html__( '', 'vaincode-theme-core' );
    }

    // Add content after the form.
    $args['footer_text'] = esc_html__( '', 'vaincode-theme-core' );

    Redux::setArgs( $opt_name, $args );

    /*
     * ---> END ARGUMENTS
     */

    /*
     * ---> START HELP TABS
     */

    $tabs = array();
    Redux::setHelpTab( $opt_name, $tabs );

    // Set the help sidebar
    $content = esc_html__( '', 'vaincode-theme-core' );
    Redux::setHelpSidebar( $opt_name, $content );


    /*
     * <--- END HELP TABS
     */


    /*
     *
     * ---> START SECTIONS
     *
     */

    /*

        As of Redux 3.5+, there is an extensive API. This API can be used in a mix/match mode allowing for


     */
    // -> Global Options
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Global Settings', 'vaincode-theme-core' ),
        'icon' => 'el el-globe-alt',
        'subtitle'       => esc_html__( '', 'vaincode-theme-core' ),
    ) );
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Global Color', 'vaincode-theme-core' ),
        'icon' => 'el el-brush',
        'subsection' => true,       
        'subtitle'       => esc_html__( '', 'vaincode-theme-core' ),
        'fields' => array( 
            array(
                'id' => 'vaincode_global_primary_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Global Primary Color', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('', 'vaincode-theme-core') ,
                'default' => '',
            ),
            array(
                'id' => 'vaincode_global_secondary_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Global Secondary Color', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('.', 'vaincode-theme-core') ,
                'default' => '',
            ),            
            array(
                'id' => 'vaincode_global_body_bg',
                'type' => 'color_rgba',
                'title' => esc_html__('Body Background', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('', 'vaincode-theme-core') ,
                'default' => '',
            ),
            array(
                'id' => 'vaincode_global_body_txt_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Body Text Color', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('Color for body, p, a & div Tag', 'vaincode-theme-core') ,
                'default' => '',
            ),                        
            array(
                'id' => 'vaincode_global_heading_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Body Headings (H1-H6) Color', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('', 'vaincode-theme-core') ,
                'default' => '',
            ),
            
            array(
                'id' => 'vaincode_global_content_link_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Body Anchor Link Color', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('', 'vaincode-theme-core') ,
                'default' => '',
            ),
            array(
                'id' => 'vaincode_global_content_link_hover_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Body Anchor Link Hover Color', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('', 'vaincode-theme-core') ,
                'default' => '',
            ),
            array(
                'id' => 'vaincode_global_sidebar_link_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Sidebar Anchor Link Color', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('', 'vaincode-theme-core') ,
                'default' => '',
            ),
            array(
                'id' => 'vaincode_global_sidebar_link_hover_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Sidebar Anchor Link Hover Color', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('', 'vaincode-theme-core') ,
                'default' => '',
            ),
            array(
                'id' => 'vaincode_global_footer_title_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Footer Titles Color', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('', 'vaincode-theme-core') ,
                'default' => '',
            ),            
            array(
                'id' => 'vaincode_global_footer_link_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Footer Anchor Link Color', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('', 'vaincode-theme-core') ,
                'default' => '',
            ),
            array(
                'id' => 'vaincode_global_footer_link_hover_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Footer Anchor Link Hover Color', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('', 'vaincode-theme-core') ,
                'default' => '',
            ),                                   
            array(
                'id' => 'vaincode_global_btn_bg',
                'type' => 'color_rgba',
                'title' => esc_html__('Button Background', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('', 'vaincode-theme-core') ,
                'default' => '',
            ),          
            array(
                'id' => 'vaincode_global_btn_hover_bg',
                'type' => 'color_rgba',
                'title' => esc_html__('Button Hover Background', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('', 'vaincode-theme-core') ,
                'default' => '',
            ),
            array(
                'id' => 'vaincode_global_blockquote_txt_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Blockquote Text Color', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('', 'vaincode-theme-core') ,
                'default' => '',
            ),            
            array(
                'id' => 'vaincode_global_blockquote_bg',
                'type' => 'color_rgba',
                'title' => esc_html__('Blockquote Background', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('', 'vaincode-theme-core') ,
                'default' => '',
            ),
            array(
                'id' => 'vaincode_global_blockquote_border_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Blockquote Border Color', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('', 'vaincode-theme-core') ,
                'default' => '',
            ),
            array(
                'id' => 'vaincode_global_blockquote_cite_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Blockquote Cite Color', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('', 'vaincode-theme-core') ,
                'default' => '',
            ),
            array(
                'id' => 'vaincode_global_image_caption_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Image Caption Color', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('', 'vaincode-theme-core') ,
                'default' => '',
            ),
            array(
                'id' => 'vaincode_global_blog_meta_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Blog Meta Color', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('', 'vaincode-theme-core') ,
                'default' => '',
            ),
            array(
                'id' => 'vaincode_global_th_bg',
                'type' => 'color_rgba',
                'title' => esc_html__('Table Head Background', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('', 'vaincode-theme-core') ,
                'default' => '',
            ),                                                                                                                                                                                          
        ),
    ) );
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Global Typography', 'vaincode-theme-core' ),
        'icon' => 'el el-font',
        'subsection' => true,       
        'subtitle'       => esc_html__( '', 'vaincode-theme-core' ),
        'fields' => array(
            array(
                'id'                => 'vaincode_body_typography',
                'type'              => 'typography',
                'title'             => esc_html__( 'Body Typography', 'vaincode-theme-core' ),
                'subtitle'          => esc_html__( 'Typography for body, p, a & div Tag', 'vaincode-theme-core' ),
                'google'            => true,
                'font_family_clear' => true,
                'text-align'        => false,
                'units'             =>'px',
                'color'             => false,
                'line-height'       => false,
                'default'           => array(
                    'google'      => true,
                    'font-size'   => '14px',
                    'font-weight' => '400',
                ),
                'output'            => array( 'body,p,div,a:not(h2 a),li,.bread-crumb h4 a,.bread-crumb h4 ' ),
            ),
            array(
                'id'                => 'vaincode_heading_typography',
                'type'              => 'typography',
                'title'             => esc_html__( 'Headings Typography', 'vaincode-theme-core' ),
                'subtitle'          => esc_html__( 'Typography for h1, h2, h3, h4, h4 & h6 Tag', 'vaincode-theme-core' ),
                'google'            => true, 
                'font-backup'       => false,
                'font_family_clear' => true,
                'text-shadow'       => false,
                'color_alpha'       => false,
                'margin-top'        => false,
                'margin-bottom'     => false,
                'text-align'        => false,
                'font-size'         => false,
                'line-height'       => false,
                'color'             => false,
                'default'           => array(
                    'google'        => true,
                    'font-weight'   => '600',
                ),
                'output'            => array( 'h1,.h1,h2,.h2,h3,.h3,h4,.h4,h5,.h5,h6,.h6,.title,.widget_block label,.side-bar .widget.widget_block h2' ),
            ),
            array(
                'id'                => 'vaincode_heading1_font_size',
                'type'              => 'typography',
                'title'             => esc_html__( 'Heading-1 Font Size', 'vaincode-theme-core' ),
                'subtitle'          => esc_html__( 'Font Size for h1 Tag', 'vaincode-theme-core' ),
                'google'            => false, 
                'font-backup'       => false,
                'font_family_clear' => false,
                'text-shadow'       => false,
                'color_alpha'       => false,
                'margin-top'        => false,
                'margin-bottom'     => false,
                'text-align'        => false,
                'line-height'       => false,
                'font-family'       => false,
                'font-weight'       => false,
                'font-style'        => false,
                'color'       => false,
                'default'           => array(
                    'font-size'     => '36px',
                ),
                'output'            => array( 'h1,.h1,h1 a,a h1' ),
            ),
            array(
                'id'                => 'vaincode_heading2_font_size',
                'type'              => 'typography',
                'title'             => esc_html__( 'Heading-2 Font Size', 'vaincode-theme-core' ),
                'subtitle'          => esc_html__( 'Font Size for h2 Tag', 'vaincode-theme-core' ),
                'google'            => false, 
                'font-backup'       => false,
                'font_family_clear' => false,
                'text-shadow'       => false,
                'color_alpha'       => false,
                'margin-top'        => false,
                'margin-bottom'     => false,
                'text-align'        => false,
                'line-height'       => false,
                'font-family'       => false,
                'font-weight'       => false,
                'font-style'        => false,
                'color'             => false,
                'default'           => array(
                    'font-size'     => '30px',
                ),
                'output'            => array( 'h2,.h2,h2 a,a h2' ),
            ),
            array(
                'id'                => 'vaincode_heading3_font_size',
                'type'              => 'typography',
                'title'             => esc_html__( 'Heading-3 Font Size', 'vaincode-theme-core' ),
                'subtitle'          => esc_html__( 'Font Size for h3 Tag', 'vaincode-theme-core' ),
                'google'            => false, 
                'font-backup'       => false,
                'font_family_clear' => false,
                'text-shadow'       => false,
                'color_alpha'       => false,
                'margin-top'        => false,
                'margin-bottom'     => false,
                'text-align'        => false,
                'line-height'       => false,
                'font-family'       => false,
                'font-weight'       => false,
                'font-style'        => false,
                'color'             => false,
                'default'           => array(
                    'font-size'     => '24px',
                ),
                'output'            => array( 'h3,.h3,h3 a,a h3' ),
            ),
            array(
                'id'                => 'vaincode_heading4_font_size',
                'type'              => 'typography',
                'title'             => esc_html__( 'Heading-4 Font Size', 'vaincode-theme-core' ),
                'subtitle'          => esc_html__( 'Font Size for h4 Tag', 'vaincode-theme-core' ),
                'google'            => false, 
                'font-backup'       => false,
                'font_family_clear' => false,
                'text-shadow'       => false,
                'color_alpha'       => false,
                'margin-top'        => false,
                'margin-bottom'     => false,
                'text-align'        => false,
                'line-height'       => false,
                'font-family'       => false,
                'font-weight'       => false,
                'font-style'        => false,
                'color'             => false,
                'default'           => array(
                    'font-size'     => '18px',
                ),
                'output'            => array( 'h4,.h4,h4 a,a h4' ),
            ),
            array(
                'id'                => 'vaincode_heading5_font_size',
                'type'              => 'typography',
                'title'             => esc_html__( 'Heading-5 Font Size', 'vaincode-theme-core' ),
                'subtitle'          => esc_html__( 'Font Size for h5 Tag', 'vaincode-theme-core' ),
                'google'            => false, 
                'font-backup'       => false,
                'font_family_clear' => false,
                'text-shadow'       => false,
                'color_alpha'       => false,
                'margin-top'        => false,
                'margin-bottom'     => false,
                'text-align'        => false,
                'line-height'       => false,
                'font-family'       => false,
                'font-weight'       => false,
                'font-style'        => false,
                'color'             => false,
                'default'           => array(
                    'font-size'     => '16px',
                ),
                'output'            => array( 'h5,.h5,h5 a,a h5' ),
            ),
            array(
                'id'                => 'vaincode_heading6_font_size',
                'type'              => 'typography',
                'title'             => esc_html__( 'Heading-6 Font Size', 'vaincode-theme-core' ),
                'subtitle'          => esc_html__( 'Font Size for h6 Tag', 'vaincode-theme-core' ),
                'google'            => false, 
                'font-backup'       => false,
                'font_family_clear' => false,
                'text-shadow'       => false,
                'color_alpha'       => false,
                'margin-top'        => false,
                'margin-bottom'     => false,
                'text-align'        => false,
                'line-height'       => false,
                'font-family'       => false,
                'font-weight'       => false,
                'font-style'        => false,
                'color'             => false,
                'default'           => array(
                    'font-size'     => '14px',
                ),
                'output'            => array( 'h6,.h6,h6 a,a h6' ),
            ),                                                                   
        ),
    ) );        
    // -> START Basic Fields
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'General', 'vaincode-theme-core' ),
		'icon' => 'el el-home',
        'subtitle'       => esc_html__( '', 'vaincode-theme-core' ),
    ) );
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Favicon Settings', 'vaincode-theme-core' ),
		'icon' => 'el el-globe-alt',
        'subsection' => true,		
        'subtitle'       => esc_html__( '', 'vaincode-theme-core' ),
		'fields' => array(
			array(
				'id' => 'vaincode_favicon',
				'type' => 'media',
				'title' => esc_html__('Upload Favicon', 'vaincode-theme-core') ,
				'subtitle' => esc_html__('This is favicon. Upload 64x64 favicon icon.', 'vaincode-theme-core') ,
			) ,
		),
    ) );
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Logo Settings', 'vaincode-theme-core' ),
		'icon' => 'el el-adjust-alt',
        'subsection' => true,		
        'subtitle'       => esc_html__( 'This is for Logo options.', 'vaincode-theme-core' ),
		'fields' => array(
			array(
				'id' => 'logo_icon',
				'type' => 'media',
				'title' => esc_html__('Logo Icon', 'vaincode-theme-core') ,
				'subtitle' => esc_html__('Upload your site logo here.', 'vaincode-theme-core') ,
				'default' => '',
			) ,

		),
    ) );
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'General Settings', 'vaincode-theme-core' ),
		'icon' => 'el el-adjust-alt',
        'subsection' => true,		
        'subtitle'       => esc_html__( 'This is for General options.', 'vaincode-theme-core' ),
		'fields' => array(
			array(
				'id' => 'preloader_switch',
				'type' => 'switch',
				'title' => esc_html__('On/Off Preloader', 'vaincode-theme-core') ,
				'subtitle' => esc_html__('', 'vaincode-theme-core') ,
				'default' => '0',
			) ,

		),
    ) );
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Header Settings', 'vaincode-theme-core' ),
        'icon' => 'el el-cog-alt',
        'subtitle'       => esc_html__( '', 'vaincode-theme-core' ),
    ) );    
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Menu Style Settings', 'vaincode-theme-core' ),
        'icon' => 'el el-lines',
        'subsection' => true,       
        'subtitle'       => esc_html__( '', 'vaincode-theme-core' ),
        'fields' => array(
            array(
                'id' => 'vaincode_header_main_menu_style',
                'type' => 'image_select',
                'title' => esc_html__('Header Main Menu Styles', 'vaincode-theme-core'),
                'subtitle' => esc_html__('', 'vaincode-theme-core'),
                'options'  => array(
                    '1'      => array(
                        'alt'   => 'Menu Style- One', 
                        'img'   => get_template_directory_uri().'/images/menu-layouts/layout-1.JPG'
                    ),
                    '2'      => array(
                        'alt'   => 'Menu Style- Two', 
                        'img'   => get_template_directory_uri().'/images/menu-layouts/layout-2.JPG'
                    ),
                    '3'      => array(
                        'alt'   => 'Menu Style- Three', 
                        'img'  => get_template_directory_uri().'/images/menu-layouts/layout-3.JPG'
                    ),
                    '4'      => array(
                        'alt'   => 'Menu Style- Four', 
                        'img'   => get_template_directory_uri().'/images/menu-layouts/layout-4.JPG'
                    ),
                    '5'      => array(
                        'alt'   => 'Menu Style- Five', 
                        'img'   => get_template_directory_uri().'/images/menu-layouts/layout-5.JPG'
                    ),
                    '6'      => array(
                        'alt'  => 'Menu Style- Six', 
                        'img'  => get_template_directory_uri().'/images/menu-layouts/layout-6.JPG'
                    ),
                    '7'      => array(
                        'alt'  => 'Menu Style- Seven', 
                        'img'  => get_template_directory_uri().'/images/menu-layouts/layout-7.JPG'
                    ),                    
                ),
                'default' => '1'
            ),
            array(
                'id' => 'vaincode_sticky_menu_switch',
                'type' => 'radio',
                'title' => esc_html__('Sticky Menu', 'vaincode-theme-core'),
                'options' => array(
                    '1' => 'Full Sticky',
                    '2' => 'No Sticky',
                ) , // Must provide key => value pairs for radio options
                'default' => '2'
            ),
            array(
                'id' => 'vaincode_header_top_menu_switch',
                'type' => 'switch',
                'title' => esc_html__('On/Off Header Top Menu', 'vaincode-theme-core'),
                'subtitle' => esc_html__('', 'vaincode-theme-core'),
                'default' => '0'
            ),
            array(
                'id' => 'vaincode_header_top_menu_lang_switch',
                'type' => 'switch',
                'title' => esc_html__('On/Off Header Top Menu Language Switch', 'vaincode-theme-core'),
                'subtitle' => esc_html__('This feature is available for Menu Style- 2', 'vaincode-theme-core'),
                'default' => '1'
            ),
            array(
                'id' => 'vaincode_header_main_menu_search_btn_switch',
                'type' => 'switch',
                'title' => esc_html__('On/Off Header Main Menu Search Button', 'vaincode-theme-core'),
                'subtitle' => esc_html__('On/Off search button from header main menu.', 'vaincode-theme-core'),
                'default' => '1'
            ),  
            array(
                'id' => 'vaincode_header_main_menu_slide_nav_btn_switch',
                'type' => 'switch',
                'title' => esc_html__('On/Off Header Main Menu Slide Navigation Menu', 'vaincode-theme-core'),
                'subtitle' => esc_html__('On/Off slide navigation menu. This feature is available for Menu Style- 2', 'vaincode-theme-core'),
                'default' => '1'
            ),
            array(
                'id' => 'vaincode_woocommerce_cart_switch',
                'type' => 'switch',
                'title' => esc_html__('On/Off WooCommerce Cart Icon on Main Navigation Menu', 'vaincode-theme-core'),
                'sub_desc' => esc_html__('On/Off WooCommerce Cart Icon on Main Navigation Menu', 'vaincode-theme-core'),
                'default' => '1'
            ),          
            array(
                'id' => 'vaincode_header_top_menu_phone',
                'type' => 'text',
                'title' => esc_html__('Header Top Menu Phone Number', 'vaincode-theme-core'),
                'subtitle' => esc_html__('Enter here header top menu phone number.You should not use gap between digits. Use (-) instead of gap. Example:+1-23-4567-890', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_top_menu_email',
                'type' => 'text',
                'title' => esc_html__('Header Top Menu Email', 'vaincode-theme-core'),
                'subtitle' => esc_html__('Enter here header top menu email. Example: xyz@example.com', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_top_menu_address',
                'type' => 'text',
                'title' => esc_html__('Header Top Menu Address', 'vaincode-theme-core'),
                'subtitle' => esc_html__('Enter here header top menu address details.', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_top_business_working_day',
                'type' => 'text',
                'title' => esc_html__('Header Top Menu - Business Working Day', 'vaincode-theme-core'),
                'subtitle' => esc_html__('Enter your business working day in a week. Example: Monday to Friday. This feature is available for Menu Style- 3 and Menu Style- 4', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_top_business_working_hours',
                'type' => 'text',
                'title' => esc_html__('Header Top Menu - Business Working Hours', 'vaincode-theme-core'),
                'subtitle' => esc_html__('Enter your business working hours in a day. Example: 8.00 AM - 5.30 PM. This feature is available for Menu Style- 3 and Menu Style- 4', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_top_menu_btn_label',
                'type' => 'text',
                'title' => esc_html__('Header Top Menu Button Label', 'vaincode-theme-core'),
                'subtitle' => esc_html__('Enter here header top menu button label.', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_top_menu_btn_link',
                'type' => 'text',
                'title' => esc_html__('Header Top Menu Button Link', 'vaincode-theme-core'),
                'subtitle' => esc_html__('Enter here header top menu button link.Example:http://google.com', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_main_menu_slide_nav_width',
                'type' => 'text',
                'title' => esc_html__('Slide Navigation Width', 'vaincode-theme-core'),
                'subtitle' => esc_html__('Enter here slide navigation width in pixel. Example: 280px. (Optional)', 'vaincode-theme-core'),
                'default' => '',
            ),  
            array(
                'id' => 'vaincode_header_main_menu_slide_nav_desc',
                'type' => 'textarea',
                'title' => esc_html__('Slide Navigation Description', 'vaincode-theme-core'),
                'subtitle' => esc_html__('Enter here business description. This feature is available for Menu Style- 2', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_main_menu_slide_nav_postal_address',
                'type' => 'text',
                'title' => esc_html__('Slide Navigation Postal Address', 'vaincode-theme-core'),
                'subtitle' => esc_html__('Enter here business postal address. This feature is available for Menu Style- 2', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_main_menu_slide_nav_telephone',
                'type' => 'text',
                'title' => esc_html__('Slide Navigation Phone Number', 'vaincode-theme-core'),
                'subtitle' => esc_html__('Enter here business phone numbers. This feature is available for Menu Style- 2', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_main_menu_slide_nav_copyright',
                'type' => 'text',
                'title' => esc_html__('Slide Navigation Copyright Text', 'vaincode-theme-core'),
                'subtitle' => esc_html__('Enter here copyright text. This feature is available for Menu Style- 2 and Menu Style- 5', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_main_menu_slide_nav_btn1_label',
                'type' => 'text',
                'title' => esc_html__('Slide Navigation Button- 1 Label', 'vaincode-theme-core'),
                'subtitle' => esc_html__('Enter here button- 1 label. This feature is available for Menu Style- 2 and Menu Style- 5', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_main_menu_slide_nav_btn1_url',
                'type' => 'text',
                'title' => esc_html__('Slide Navigation Button- 1 URL', 'vaincode-theme-core'),
                'subtitle' => esc_html__('Enter here button- 1 url. This feature is available for Menu Style- 2 and Menu Style- 5', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_main_menu_slide_nav_btn2_label',
                'type' => 'text',
                'title' => esc_html__('Slide Navigation Button- 2 Label', 'vaincode-theme-core'),
                'subtitle' => esc_html__('Enter here button- 2 label. This feature is available for Menu Style- 2 and Menu Style- 5', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_main_menu_slide_nav_btn2_url',
                'type' => 'text',
                'title' => esc_html__('Slide Navigation Button- 2 URL', 'vaincode-theme-core'),
                'subtitle' => esc_html__('Enter here button- 2 url. This feature is available for Menu Style- 2 and Menu Style- 5', 'vaincode-theme-core'),
                'default' => '',
            ),          
        ),
    ) );	
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Menu Color Settings', 'vaincode-theme-core' ),
		'icon' => 'el el-brush',
        'subsection' => true,		
        'subtitle'       => esc_html__( 'This is for Menu options.', 'vaincode-theme-core' ),
		'fields' => array(
			array(
				'id' => 'main_menu_bg_color',
				'type' => 'color_rgba',
				'title' => esc_html__('Main Menu Background Color', 'vaincode-theme-core') ,
				'subtitle' => esc_html__('This feature is available for Menu Style- 7', 'vaincode-theme-core') ,
				'default' => '',
			) ,
			array(
				'id' => 'main_menu_anchor_color',
				'type' => 'color_rgba',
				'title' => esc_html__('Main Menu Anchor Color', 'vaincode-theme-core') ,
				'subtitle' => esc_html__('This feature is available for Menu Style- 7', 'vaincode-theme-core') ,
				'default' => '',
			) ,
			array(
				'id' => 'sub_menu_bg_color',
				'type' => 'color_rgba',
				'title' => esc_html__('Sub Menu Background Color', 'vaincode-theme-core') ,
				'subtitle' => esc_html__('This feature is available for Menu Style- 7', 'vaincode-theme-core') ,
				'default' => '',
			) ,
            array(
                'id' => 'vaincode_header_top_menu_bg_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Header Top Menu Background Color', 'vaincode-theme-core'),
                'subtitle' => esc_html__('', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_top_menu_two_bg_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Header Top Menu- 2 Background Color', 'vaincode-theme-core'),
                'subtitle' => esc_html__('This feature is available for Menu Style- 2', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_top_menu_icon_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Header Top Menu Icon Color', 'vaincode-theme-core'),
                'subtitle' => esc_html__('', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_top_menu_text_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Header Top Menu Text Color', 'vaincode-theme-core'),
                'subtitle' => esc_html__('', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_top_menu_social_icon_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Header Top Menu Social Icon Color', 'vaincode-theme-core'),
                'subtitle' => esc_html__('', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_top_menu_social_bg_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Header Top Menu Social Icon Background Color', 'vaincode-theme-core'),
                'subtitle' => esc_html__('This feature is available for Menu Style- 1', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_top_menu_social_icon_hover_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Header Top Menu Social Icon Hover Color', 'vaincode-theme-core'),
                'subtitle' => esc_html__('This feature is available for Menu Style- 1', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_top_menu_social_icon_hover_bg_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Header Top Menu Social Icon Hover Background Color', 'vaincode-theme-core'),
                'subtitle' => esc_html__('This feature is available for Menu Style- 1', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_top_menu_btn_text_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Header Top Menu Button Text Color', 'vaincode-theme-core'),
                'subtitle' => esc_html__('', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_top_menu_btn_bg_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Header Top Menu Button Background Color', 'vaincode-theme-core'),
                'subtitle' => esc_html__('', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_top_menu_btn_hover_text_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Header Top Menu Button Hover Text Color', 'vaincode-theme-core'),
                'subtitle' => esc_html__('', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_top_menu_btn_hover_bg_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Header Top Menu Button Hover Background Color', 'vaincode-theme-core'),
                'subtitle' => esc_html__('', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_main_menu_bg_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Header Main Menu Background Color', 'vaincode-theme-core'),
                'subtitle' => esc_html__('', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_main_menu_anchor_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Header Main Menu Anchor Color', 'vaincode-theme-core'),
                'subtitle' => esc_html__('', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_main_menu_anchor_hover_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Header Main Menu Anchor Hover Text Color', 'vaincode-theme-core'),
                'subtitle' => esc_html__('', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_main_menu_anchor_hover_bg_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Header Main Menu Anchor Hover Background Color', 'vaincode-theme-core'),
                'subtitle' => esc_html__('This feature is available for Menu Style-2', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_sub_menu_bg_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Header Sub Menu Background Color', 'vaincode-theme-core'),
                'subtitle' => esc_html__('', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_sub_menu_anchor_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Header Sub Menu Anchor Color', 'vaincode-theme-core'),
                'subtitle' => esc_html__('', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_main_menu_search_btn_bg_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Header Main Menu Search Button Background color.', 'vaincode-theme-core'),
                'subtitle' => esc_html__('This feature is available for Menu Style- 2', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_main_menu_popup_search_btn_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Header Main Menu Pop-up Search Button Background color.', 'vaincode-theme-core'),
                'subtitle' => esc_html__('', 'vaincode-theme-core'),
                'default' => '',
            ),  
            array(
                'id' => 'vaincode_header_main_menu_slide_nav_bg_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Header Main Menu Slide Navigation Button Background color', 'vaincode-theme-core'),
                'subtitle' => esc_html__('This feature is available for Menu Style- 2', 'vaincode-theme-core'),
                'default' => '',
            ),  
            array(
                'id' => 'vaincode_header_main_menu_slide_navigation_bg_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Slide Navigation Background color', 'vaincode-theme-core'),
                'subtitle' => esc_html__('This feature is available for Menu Style- 2 and Menu Style- 5', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_main_menu_slide_navigation_text_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Slide Navigation Text color', 'vaincode-theme-core'),
                'subtitle' => esc_html__('This feature is available for Menu Style- 2 and Menu Style- 5', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_header_main_menu_slide_navigation_icon_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Slide Navigation Icon color', 'vaincode-theme-core'),
                'subtitle' => esc_html__('This feature is available for Menu Style- 2', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_slide_navigation_btn1_text_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Slide Navigation Button- 1 Text Color', 'vaincode-theme-core'),
                'subtitle' => esc_html__('This feature is available for Menu Style- 2 and Menu Style- 5', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_slide_navigation_btn1_bg_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Slide Navigation Button- 1 Background Color', 'vaincode-theme-core'),
                'subtitle' => esc_html__('This feature is available for Menu Style- 2 and Menu Style- 5', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_slide_navigation_btn1_hovertext_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Slide Navigation Button- 1 Hover Text Color', 'vaincode-theme-core'),
                'subtitle' => esc_html__('This feature is available for Menu Style- 2 and Menu Style- 5', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_slide_navigation_btn1_hoverbg_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Slide Navigation Button- 1 Hover Background Color', 'vaincode-theme-core'),
                'subtitle' => esc_html__('This feature is available for Menu Style- 2 and Menu Style- 5', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_slide_navigation_btn2_text_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Slide Navigation Button- 2 Text Color', 'vaincode-theme-core'),
                'subtitle' => esc_html__('This feature is available for Menu Style- 2 and Menu Style- 5', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_slide_navigation_btn2_bg_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Slide Navigation Button- 2 Background Color', 'vaincode-theme-core'),
                'subtitle' => esc_html__('This feature is available for Menu Style- 2 and Menu Style- 5', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_slide_navigation_btn2_hovertext_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Slide Navigation Button- 2 Hover Text Color', 'vaincode-theme-core'),
                'subtitle' => esc_html__('This feature is available for Menu Style- 2 and Menu Style- 5', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_slide_navigation_btn2_hoverbg_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Slide Navigation Button- 2 Hover Background Color', 'vaincode-theme-core'),
                'subtitle' => esc_html__('This feature is available for Menu Style- 2 and Menu Style- 5', 'vaincode-theme-core'),
                'default' => '',
            ),  
            array(
                'id' => 'vaincode_mobile_nav_bg_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Main Navigation Menu Background Color in Mobile Device.', 'vaincode-theme-core'),
                'subtitle' => esc_html__('', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_mobile_nav_text_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Main Navigation Menu Text Color in Mobile Device.', 'vaincode-theme-core'),
                'subtitle' => esc_html__('', 'vaincode-theme-core'),
                'default' => '',
            ),
            array(
                'id' => 'vaincode_mobile_nav_btn_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Main Navigation Menu Toggle Button Border Color in Mobile Device.', 'vaincode-theme-core'),
                'subtitle' => esc_html__('', 'vaincode-theme-core'),
                'default' => '',
            ),            		
		),
    ) );

    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Footer Settings', 'vaincode-theme-core' ),
		'icon' => 'el el-cog-alt',
        'subtitle'       => esc_html__( '', 'vaincode-theme-core' ),
    ) );
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Footer Column Settings', 'vaincode-theme-core' ),
		'icon' => 'el el-adjust-alt',
        'subsection' => true,		
        'subtitle'       => esc_html__( '', 'vaincode-theme-core' ),
		'fields' => array(
			array(
				'id' => 'vaincode_footer_columns',
				'type' => 'radio',
				'title' => esc_html__('Number of Columns in Footer', 'vaincode-theme-core') ,
				'subtitle' => esc_html__('', 'vaincode-theme-core') ,
				'options' => array(
					'1' => 'One Column <br>(Insert your Widgets in "Footer 1st Column Widgets" area from Appearance > Widgets page)',
					'2' => 'Two Columns <br>(Insert your Widgets in "Footer 1st Column Widgets and Footer 2nd Column Widgets" area from Appearance > Widgets page)',
					'3' => 'Three Columns <br>(Insert your Widgets in "Footer 1st Column Widgets, Footer 2nd Column Widgets and Footer 3rd Column Widgets" area from Appearance > Widgets page)',
					'4' => 'Four Columns <br>(Insert your Widgets in "Footer 1st Column Widgets, Footer 2nd Column Widgets, Footer 3rd Column Widgets and Footer 4th Column Widgets" area from Appearance > Widgets page)',					
				) , 
				'default' => '4'
			) ,
            array(
                'id' => 'footer_copyright_text',
                'type' => 'text',
                'title' => esc_html__('Footer Copyright Text', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('', 'vaincode-theme-core') ,
                'default' => esc_html__('© Copyright 2021, vaincode.com', 'vaincode-theme-core'),
            ),            	
            array(
                'id' => 'footer_bg_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Footer Top Section Background Color', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('', 'vaincode-theme-core') ,
                'default' => '',
            ),
            array(
                'id' => 'footer_copyright_text_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Footer Copyright Section Text Color', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('', 'vaincode-theme-core') ,
                'default' => '',
            ),            
            array(
                'id' => 'footer_copyright_bg_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Footer Copyright Section Background Color', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('', 'vaincode-theme-core') ,
                'default' => '',
            ),            
            array(
                'id' => 'footer_anchor_color',
                'type' => 'color_rgba',
                'title' => esc_html__('Footer Links Color', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('', 'vaincode-theme-core') ,
                'default' => '',
            ),			
			array(
				'id' => 'footer_linear_background_switch',
				'type' => 'switch',
				'title' => esc_html__('On/Off Footer Linear Gradient Background', 'vaincode-theme-core') ,
				'subtitle' => '',
				'default' => '0',
			),
            array(
                'id' => 'footer_linear_bgcolor1',
                'type' => 'color_rgba',
                'title' => esc_html__('Footer Linear Gradient Background  Primary Color', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('', 'vaincode-theme-core') ,
                'default' => '',
            ),
            array(
                'id' => 'footer_linear_bgcolor2',
                'type' => 'color_rgba',
                'title' => esc_html__('Footer Linear Gradient Background  Secondary Color', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('', 'vaincode-theme-core') ,
                'default' => '',
            ),			
		),
    ) );
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Blog Settings', 'vaincode-theme-core' ),
		'icon' => 'el el-cog-alt',
        'subtitle'       => esc_html__( '', 'vaincode-theme-core' ),
    ) );
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Blog Page Settings', 'vaincode-theme-core' ),
		'icon' => 'el el-adjust-alt',
        'subsection' => true,		
        'subtitle'       => esc_html__( '', 'vaincode-theme-core' ),
		'fields' => array(
			array(
				'id'       => 'blog_page_layout',
				'type'     => 'radio',
				'title'    => esc_html__('Blog Page Layout', 'vaincode-theme-core'), 
				'subtitle' => esc_html__('', 'vaincode-theme-core'),
				'desc'     => esc_html__('', 'vaincode-theme-core'),
				//Must provide key => value pairs for radio options
				'options'  => array(
					'1' => 'Blog With Sidebar', 
					'2' => 'Blog Without Sidebar', 
				),
				'default' => '1'
			),
			array(
				'id' => 'blog_page_headline_one',
				'type' => 'text',
				'title' => esc_html__('Blog Page Headline One', 'vaincode-theme-core') ,
				'subtitle' => esc_html__('', 'vaincode-theme-core') ,
				'default' => '',
			),
			array(
				'id' => 'blog_page_headline_two',
				'type' => 'text',
				'title' => esc_html__('Blog Page Headline Two', 'vaincode-theme-core') ,
				'subtitle' => esc_html__('', 'vaincode-theme-core') ,
				'default' => '',
			),			
			array(
				'id' => 'author_meta_switch',
				'type' => 'switch',
				'title' => esc_html__('On/Off Author Meta', 'vaincode-theme-core') ,
				'subtitle' => '',
				'default' => '1',
			),
			array(
				'id' => 'date_meta_switch',
				'type' => 'switch',
				'title' => esc_html__('On/Off Date Meta', 'vaincode-theme-core') ,
				'subtitle' => '',
				'default' => '1',
			),
			array(
				'id' => 'cat_meta_switch',
				'type' => 'switch',
				'title' => esc_html__('On/Off Category Meta', 'vaincode-theme-core') ,
				'subtitle' => '',
				'default' => '1',
			),
			array(
				'id' => 'tag_meta_switch',
				'type' => 'switch',
				'title' => esc_html__('On/Off Tag Meta', 'vaincode-theme-core') ,
				'subtitle' => '',
				'default' => '1',
			),
			array(
				'id' => 'read_more_btn_label',
				'type' => 'text',
				'title' => esc_html__('Read More Button Label', 'vaincode-theme-core') ,
				'subtitle' => '',
				'default' => 'Read More',
			),			
		
		),
    ) );	
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Blog Post Settings', 'vaincode-theme-core' ),
		'icon' => 'el el-adjust-alt',
        'subsection' => true,		
        'subtitle'       => esc_html__( '', 'vaincode-theme-core' ),
		'fields' => array(
			array(
				'id'       => 'blog_post_layout',
				'type'     => 'radio',
				'title'    => esc_html__('Blog Post Layout', 'vaincode-theme-core'), 
				'subtitle' => esc_html__('', 'vaincode-theme-core'),
				'desc'     => esc_html__('', 'vaincode-theme-core'),
				//Must provide key => value pairs for radio options
				'options'  => array(
					'1' => 'Blog Post With Sidebar', 
					'2' => 'Blog Post Without Sidebar', 
				),
				'default' => '1'
			),
			array(
				'id' => 'blog_post_author_meta_switch',
				'type' => 'switch',
				'title' => esc_html__('On/Off Author Meta', 'vaincode-theme-core') ,
				'subtitle' => '',
				'default' => '1',
			),
			array(
				'id' => 'blog_post_date_meta_switch',
				'type' => 'switch',
				'title' => esc_html__('On/Off Date Meta', 'vaincode-theme-core') ,
				'subtitle' => '',
				'default' => '1',
			),
			array(
				'id' => 'blog_post_cat_meta_switch',
				'type' => 'switch',
				'title' => esc_html__('On/Off Category Meta', 'vaincode-theme-core') ,
				'subtitle' => '',
				'default' => '1',
			),
			array(
				'id' => 'blog_post_tag_meta_switch',
				'type' => 'switch',
				'title' => esc_html__('On/Off Tag Meta', 'vaincode-theme-core') ,
				'subtitle' => '',
				'default' => '1',
			),
			array(
				'id' => 'blog_post_social_share_switch',
				'type' => 'switch',
				'title' => esc_html__('On/Off Social Share Meta', 'vaincode-theme-core') ,
				'subtitle' => '',
				'default' => '0',
			),			
			array(
				'id' => 'related_post_switch',
				'type' => 'switch',
				'title' => esc_html__('On/Off Related Post', 'vaincode-theme-core') ,
				'subtitle' => '',
				'default' => '1',
			),
			array(
				'id' => 'blog_post_single_next_posts',
				'type' => 'switch',
				'title' => esc_html__('On/Off Next Prev Post Meta', 'vaincode-theme-core') ,
				'subtitle' => '',
				'default' => '1',
			),
			
		),
    ) );
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Breadcrumb Settings', 'vaincode-theme-core' ),
		'icon' => 'el el-circle-arrow-right',
        'subtitle'       => esc_html__( '', 'vaincode-theme-core' ),
		'fields' => array(

			array(
				'id' => 'breadcrumb_switch',
				'type' => 'switch',
				'title' => esc_html__('On/Off Breadcrumb', 'vaincode-theme-core') ,
				'subtitle' => '',
				'default' => '1',
			),
			array(
				'id' => 'breadcrumb_bg_img',
				'type' => 'media',
				'title' => esc_html__('Breadcrumb Background Image', 'vaincode-theme-core') ,
				'subtitle' => esc_html__('Upload background image for breadcrumb section.', 'vaincode-theme-core') ,
				'default' => '',
			),
			array(
				'id' => 'bg_anim_switch',
				'type' => 'switch',
				'title' => esc_html__('On/Off Breadcrumb Background Image Animation', 'vaincode-theme-core') ,
				'subtitle' => '',
				'default' => '0',
			),			
		),
    ) );
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Page Settings', 'vaincode-theme-core' ),
		'icon' => 'el el-cog-alt',
        'subtitle'       => esc_html__( '', 'vaincode-theme-core' ),	
    ) );
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Page Header Settings', 'vaincode-theme-core' ),
		'icon' => 'el el-website',
        'subsection' => true,		
        'subtitle'       => esc_html__( '', 'vaincode-theme-core' ),
		'fields' => array(
            array(
                'id'       => 'page_layout',
                'type'     => 'radio',
                'title'    => esc_html__('Page Layout', 'vaincode-theme-core'), 
                'subtitle' => esc_html__('', 'vaincode-theme-core'),
                'desc'     => esc_html__('', 'vaincode-theme-core'),
                //Must provide key => value pairs for radio options
                'options'  => array(
                    '1' => 'Page With Sidebar', 
                    '2' => 'Page Without Sidebar', 
                ),
                'default' => '1'
            ),
			array(
				'id' => 'vaincode_page_header_section_switch',
				'type' => 'switch',
				'title' => esc_html__('On/Off Page Header Section', 'vaincode-theme-core') ,
				'subtitle' => esc_html__('', 'vaincode-theme-core') ,
				'default' => '1'
			) ,
            array(
                'id' => 'vaincode_page_header_section_wc_shop_page_switch',
                'type' => 'switch',
                'title' => esc_html__('On/Off Page Header Section in Shop Page', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('', 'vaincode-theme-core') ,
                'default' => '1'
            ) ,	
            array(
                'id' => 'vaincode_page_header_section_wc_single_product_page_switch',
                'type' => 'switch',
                'title' => esc_html__('On/Off Page Header Section in Single Product Page', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('', 'vaincode-theme-core') ,
                'default' => '1'
            ) ,
            array(
                'id' => 'vaincode_page_header_section_wc_myaccount_page_switch',
                'type' => 'switch',
                'title' => esc_html__('On/Off Page Header Section in My-account Page', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('', 'vaincode-theme-core') ,
                'default' => '1'
            ) ,            
            array(
                'id' => 'vaincode_page_header_section_wc_cart_page_switch',
                'type' => 'switch',
                'title' => esc_html__('On/Off Page Header Section in Cart Page', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('', 'vaincode-theme-core') ,
                'default' => '1'
            ) ,
            array(
                'id' => 'vaincode_page_header_section_wc_checkout_page_switch',
                'type' => 'switch',
                'title' => esc_html__('On/Off Page Header Section in Checkout Page', 'vaincode-theme-core') ,
                'subtitle' => esc_html__('', 'vaincode-theme-core') ,
                'default' => '1'
            ) ,                                    
			array(
				'id' => 'vaincode_page_header_sec_bg_image',
				'type' => 'media',
				'title' => esc_html__('Page Header Section Background Image', 'vaincode-theme-core') ,
				'subtitle' => esc_html__('', 'vaincode-theme-core') ,
			) ,	
            array(
                'id'             => 'vaincode_page_header_sec_padding',
                'type'           => 'spacing',
                'mode'           => 'padding',
                'units'          => array('px'),  
                'units_extended' => true,
				'display_units' => true,
                'right'         => false,     // Disable the right
                'left'          => false,     // Disable the left				
                'title'          => __( 'Page Header Section Padding Spacing', 'vaincode-theme-core' ),
				'subtitle' => esc_html__('This feature is for Page Header Section', 'vaincode-theme-core') ,				
                'default'        => array(
                'padding-top'    => '',
                'padding-bottom' => '',
            ),
            ),			

			array(
					'id'       => 'vaincode_page_header_sec_overlay_color',
					'type'     => 'color_gradient',
					'title'    => esc_html__('Page Header Background Gradient Color Option', 'vaincode-theme-core'),
					'subtitle' => esc_html__('', 'vaincode-theme-core'),
					'desc'     => esc_html__('', 'vaincode-theme-core'),
					'validate' => 'color',
					'default'  => array(
						'from' => '',
						'to'   => '', 
					),
				),			
			array(
				'id' => 'vaincode_page_header_sec_title_one_color',
				'type' => 'color_rgba',
				'title' => esc_html__('Page Header Section Title One Color', 'vaincode-theme-core') ,
				'subtitle' => esc_html__('', 'vaincode-theme-core') ,
				'default' => '',
			) ,	
			array(
				'id' => 'vaincode_page_header_sec_title_two_color',
				'type' => 'color_rgba',
				'title' => esc_html__('Page Header Section Title Two Color', 'vaincode-theme-core') ,
				'subtitle' => esc_html__('', 'vaincode-theme-core') ,
				'default' => '',
			) ,	
			
			array(
				'id' => 'vaincode_page_header_sec_breadcrumb_txt_color',
				'type' => 'color_rgba',
				'title' => esc_html__('Page Header Section Breadcrumb Text Color', 'vaincode-theme-core') ,
				'subtitle' => esc_html__('', 'vaincode-theme-core') ,
				'default' => '',
			) ,			
		),	
    ) );	
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Page Color Settings', 'vaincode-theme-core' ),
		'icon' => 'el el-brush',
        'subsection' => true,		
        'subtitle'       => esc_html__( '', 'vaincode-theme-core' ),
		'fields' => array(
			array(
				'id' => 'vaincode_404_btn_bg_color',
				'type' => 'color_rgba',
				'title' => esc_html__('404 page Button Background Color', 'vaincode-theme-core') ,
				'subtitle' => esc_html__('', 'vaincode-theme-core') ,
				'default' => '',
			) ,
			array(
				'id' => 'vaincode_404_btn_hover_bg_color',
				'type' => 'color_rgba',
				'title' => esc_html__('404 page Button Hover Background Color', 'vaincode-theme-core') ,
				'subtitle' => esc_html__('', 'vaincode-theme-core') ,
				'default' => '',
			) ,
		),	
    ) );		
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Newsletter Settings', 'vaincode-theme-core' ),
		'icon' => 'el el-envelope-alt',
        'subtitle'       => esc_html__( '', 'vaincode-theme-core' ),
		'fields' => array(
			array(
				'id' => 'mailchimp_apikey',
				'type' => 'text',
				'title' => esc_html__('MailChimp API Key', 'vaincode-theme-core') ,
				'subtitle' =>  wp_kses('The unique API Key of your MailChimp account. <a href="'.esc_url('https://mailchimp.com/help/about-api-keys/').'">Find Your API Key!</a>',$allowed_html ),
				'default' => '',
			) ,
			array(
				'id' => 'mailchimp_listid',
				'type' => 'text',
				'title' => esc_html__('MailChimp List ID', 'vaincode-theme-core') ,
				'subtitle' => wp_kses('The unique List ID of your MailChimp account. <a href="'.esc_url('https://mailchimp.com/help/find-your-list-id/').'">Find Your List ID! </a>',$allowed_html ),
				'default' => '',
			) ,
			array(
				'id' => 'mailchimp_optin',
				'type' => 'switch',
				'title' => esc_html__('On/Off Mailchimp Double Optin', 'vaincode-theme-core') ,
				'subtitle' => '',
				'default' => '1',
			),			
		),
    ) );	

    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Social Media Settings', 'vaincode-theme-core' ),
		'icon' => 'el el-group-alt',
        'subtitle'       => esc_html__( 'This is options for setting up the social media of website. Do not forget to use http:// for any social urls.', 'vaincode-theme-core' ),
		'fields' => array(
			array(
				'id' => 'social_facebook',
				'type' => 'text',
				'title' => esc_html__('Facebook URL', 'vaincode-theme-core') ,
				'subtitle' => esc_html__('The URL to your account page', 'vaincode-theme-core') ,
				'default' => '',
			) ,
			array(
				'id' => 'social_twitter',
				'type' => 'text',
				'title' => esc_html__('Twitter URL', 'vaincode-theme-core') ,
				'subtitle' => esc_html__('The URL to your account page', 'vaincode-theme-core') ,
				'default' => '',
			) ,
			array(
				'id' => 'social_twitter_username',
				'type' => 'text',
				'title' => esc_html__('Twitter Username', 'vaincode-theme-core') ,
				'subtitle' => esc_html__('Example: vaincode', 'vaincode-theme-core') ,
				'default' => 'vaincode-theme-core',
			) ,			
			array(
				'id' => 'social_linkedin',
				'type' => 'text',
				'title' => esc_html__('Linkedin URL', 'vaincode-theme-core') ,
				'subtitle' => esc_html__('The URL to your account page', 'vaincode-theme-core') ,
				'default' => '',
			) ,
			array(
				'id' => 'social_pinterest',
				'type' => 'text',
				'title' => esc_html__('Pinterest URL', 'vaincode-theme-core') ,
				'subtitle' => esc_html__('The URL to your account page', 'vaincode-theme-core') ,
				'default' => '',
			) ,

		),		
    ) );	
    /*
     * <--- END SECTIONS
     */
