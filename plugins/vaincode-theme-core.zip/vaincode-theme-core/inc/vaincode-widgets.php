<?php
/**
 * Register Widgets.
 *
 */

/*************************
Vaincode Text Widget
*************************/
class VaincodeTextWidget extends WP_Widget {

  function __construct() {
    parent::__construct(
      'vaincode_text_widget', // Base ID
      esc_html__('Vaincode Text Widget', 'vaincode'), // Name
      array( 'description' => esc_html__( 'Displays company details', 'vaincode'), ) // Args
    );
  }


  public function widget( $args, $instance ) {
	  extract($args);
	  $title = isset($instance['title']) ? $instance['title'] : '';
	  $image_url= isset($instance['image_url']) ? $instance['image_url'] : '';
	  $text= isset($instance['text']) ? $instance['text'] : '';
	  $title_color= isset($instance['title_color']) ? $instance['title_color'] : '';
	  $text_color= isset($instance['text_color']) ? $instance['text_color'] : '';
	  $allowed_html = array(
		'span' => array(
			'class' => array(),
			'style' => array()
		),
		'br' => array(),
		'strong' => array(),
		'p' => array(),
	);	  
  ?>
				<div class="widget about-us-one">
						<?php if(!empty($title)){ ?>
							<h3 class="widget-title" <?php if($title_color) { echo 'style="color:'.esc_attr($title_color).'"'; } ?>><?php echo esc_html($title);?></h3>
						<?php } ?>
					<a href="<?php echo esc_url(home_url( '/' ));?>">
                        <img src="<?php echo esc_url($image_url)?>" alt="<?php echo esc_attr__('logo','vaincode')?>">
                    </a>						
							<div class="widget-text">
							<?php if(!empty($text)){ ?>
								<p class="copyright-text" <?php if($text_color) { echo 'style="color:'.esc_attr($text_color).'"'; } ?>>
								<?php echo $text; ?>
								</p>
							<?php } ?>		
  
				</div>
				</div>
							
<?php	
 }

  function update( $new_instance, $old_instance ){

    $instance = $old_instance;
    $instance['title']= strip_tags( $new_instance['title'] );
    $instance['image_url']= strip_tags( $new_instance['image_url'] );
    $instance['text']= strip_tags( $new_instance['text'] );
    $instance['title_color']= strip_tags( $new_instance['title_color'] );
	$instance['text_color']= strip_tags( $new_instance['text_color'] );
return $instance;
  }


  function form($instance){
    $defaults = array( 
      'title'               => '',
      'image_url'               => '',
      'text'               => '',
	  'title_color'               => '',
	  'text_color'               => '',

    );
    $instance = wp_parse_args( (array) $instance, $defaults );
	$allowed_html = array(
    'span' => array(
        'class' => array(),
        'style' => array()
    ),
    'br' => array(),
    'strong' => array(),
    'p' => array(),
);
  ?>
    <p>
      <label for="<?php echo esc_attr($this->get_field_id( 'title' )); ?>"><?php esc_html_e('Title', 'vaincode'); ?></label>
      <input type="text" id="<?php echo esc_attr($this->get_field_id( 'title' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'title' )); ?>" class="widefat" value="<?php echo esc_attr($instance['title']); ?>">
	  
    </p>
    <p>
      <label for="<?php echo esc_attr($this->get_field_id( 'image_url' )); ?>"><?php esc_html_e('Logo  URL', 'vaincode'); ?></label>
      <input type="text" id="<?php echo esc_attr($this->get_field_id( 'image_url' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'image_url' )); ?>" class="widefat" value="<?php echo esc_url($instance['image_url']); ?>">
	  
    </p>	
    <p>
      <label for="<?php echo esc_attr($this->get_field_id( 'text' )); ?>"><?php esc_html_e('Copyright Text', 'vaincode'); ?></label>
      <textarea type="text" id="<?php echo esc_attr($this->get_field_id( 'text' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'text' )); ?>" class="widefat" ><?php echo $instance['text']; ?></textarea>
    </p>
 <p>
  <label for="<?php echo esc_attr($this->get_field_id( 'title_color ' )); ?>"><?php esc_html_e('Title Color', 'vaincode'); ?></label><br/>
  <input type="text" id="<?php echo esc_attr($this->get_field_id( 'title_color' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'title_color' )); ?>" class="widefat title_color" value="<?php echo esc_attr($instance['title_color']); ?>">
</p>
 <p>
  <label for="<?php echo esc_attr($this->get_field_id( 'text_color ' )); ?>"><?php esc_html_e('Text Color', 'vaincode'); ?></label><br/>
  <input type="text" id="<?php echo esc_attr($this->get_field_id( 'text_color' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'text_color' )); ?>" class="widefat text_color" value="<?php echo esc_attr($instance['text_color']); ?>">
</p>
	<script>
		jQuery(document).ready(function($){
			jQuery('.title_color').each(function(){
        		jQuery(this).wpColorPicker();
    		});	
			jQuery('.text_color').each(function(){
        		jQuery(this).wpColorPicker();
    		});	    					
		});
	</script>	
  <?php
  }

}//end of class

 
function register_vaincode_text_widget() {
  register_widget( 'VaincodeTextWidget' );  // Class Name
}
add_action( 'widgets_init', 'register_vaincode_text_widget' );

/*************************
Vaincode Social Widget
*************************/
class VaincodeSocialWidget extends WP_Widget {

  function __construct() {
    parent::__construct(
      'vaincode_social_widget', // Base ID
      esc_html__('Vaincode Social widget', 'vaincode'), // Name
      array( 'description' => esc_html__( 'Displays social profile url.', 'vaincode'), ) // Args
    );
  }


  public function widget( $args, $instance ) {
	  extract($args);
	  $title = isset($instance['title']) ? $instance['title'] : '';
	  $fb_url= isset($instance['fb_url']) ? $instance['fb_url'] : '';
	  $twitter_url= isset($instance['twitter_url']) ? $instance['twitter_url'] : '';  
	  $pinterest_url= isset($instance['pinterest_url']) ? $instance['pinterest_url'] : '';  
	  $instagram_url= isset($instance['instagram_url']) ? $instance['instagram_url'] : '';  
	  $widget_margin_bottom= isset($instance['widget_margin_bottom']) ? $instance['widget_margin_bottom'] : '';  
  ?>
				<div class="widget vaincode-social-widget" <?php if($widget_margin_bottom){echo 'style="margin-bottom:'.esc_attr($widget_margin_bottom).'"';}?>>
						<?php if(!empty($title)){ ?>
							<h3 class="widget-title"><?php echo esc_html($title);?></h3>
						<?php } ?>
					<ul id="social">
                        <li>
                            <a target="_blank" href="<?php echo esc_url($fb_url);?>">
                                <i class="fab fa-facebook"></i>
                            </a>
                        </li>
                        <li>
                            <a target="_blank" href="<?php echo esc_url($twitter_url);?>">
                                <i class="fab fa-twitter"></i>
                            </a>
                        </li>
                        <li>
                            <a target="_blank" href="<?php echo esc_url($pinterest_url);?>">
                                <i class="fab fa-pinterest-p"></i>
                            </a>
                        </li>
                        <li>
                            <a target="_blank" href="<?php echo esc_url($instagram_url);?>">
                                <i class="fab fa-instagram"></i>
                            </a>
                        </li>
                    </ul>
				</div>
							
<?php	
 }

  function update( $new_instance, $old_instance ){

    $instance = $old_instance;
    $instance['title']= strip_tags( $new_instance['title'] );
    $instance['fb_url']= strip_tags( $new_instance['fb_url'] );
    $instance['twitter_url']= strip_tags( $new_instance['twitter_url'] );
    $instance['pinterest_url']= strip_tags( $new_instance['pinterest_url'] );
    $instance['instagram_url']= strip_tags( $new_instance['instagram_url'] );
    $instance['widget_margin_bottom']= strip_tags( $new_instance['widget_margin_bottom'] );

return $instance;
  }


  function form($instance){
    $defaults = array( 
      'title'               => '',
      'fb_url'               => '',
      'twitter_url'               => '',
      'pinterest_url'               => '',
      'instagram_url'               => '',
      'widget_margin_bottom'               => '',
    );
    $instance = wp_parse_args( (array) $instance, $defaults );

  ?>
    <p>
      <label for="<?php echo esc_attr($this->get_field_id( 'title' )); ?>"><?php esc_html_e('Title', 'vaincode'); ?></label>
      <input type="text" id="<?php echo esc_attr($this->get_field_id( 'title' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'title' )); ?>" class="widefat" value="<?php echo esc_attr($instance['title']); ?>">
	  
    </p>
    <p>
      <label for="<?php echo esc_attr($this->get_field_id( 'fb_url' )); ?>"><?php esc_html_e('Facebook  URL', 'vaincode'); ?></label>
      <input type="text" id="<?php echo esc_attr($this->get_field_id( 'fb_url' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'fb_url' )); ?>" class="widefat" value="<?php echo esc_url($instance['fb_url']); ?>">	  
    </p>	
    <p>
      <label for="<?php echo esc_attr($this->get_field_id( 'twitter_url' )); ?>"><?php esc_html_e('Twitter  URL', 'vaincode'); ?></label>
      <input type="text" id="<?php echo esc_attr($this->get_field_id( 'twitter_url' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'twitter_url' )); ?>" class="widefat" value="<?php echo esc_url($instance['twitter_url']); ?>">	  
    </p>
    <p>
      <label for="<?php echo esc_attr($this->get_field_id( 'pinterest_url' )); ?>"><?php esc_html_e('Pinterest  URL', 'vaincode'); ?></label>
      <input type="text" id="<?php echo esc_attr($this->get_field_id( 'pinterest_url' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'pinterest_url' )); ?>" class="widefat" value="<?php echo esc_url($instance['pinterest_url']); ?>">	  
    </p> 
    <p>
      <label for="<?php echo esc_attr($this->get_field_id( 'instagram_url' )); ?>"><?php esc_html_e('Instagram  URL', 'vaincode'); ?></label>
      <input type="text" id="<?php echo esc_attr($this->get_field_id( 'instagram_url' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'instagram_url' )); ?>" class="widefat" value="<?php echo esc_url($instance['instagram_url']); ?>">	  
    </p> 	
	<p>
      <label for="<?php echo esc_attr($this->get_field_id( 'widget_margin_bottom' )); ?>"><?php esc_html_e('Margin Bottom in Pixel.', 'vaincode'); ?></label>
      <input type="text" id="<?php echo esc_attr($this->get_field_id( 'widget_margin_bottom' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'widget_margin_bottom' )); ?>" class="widefat" value="<?php echo esc_attr($instance['widget_margin_bottom']); ?>">
		<small><?php echo esc_html__('Example: 50px','vaincode');?></small>
    </p>
  <?php
  }

}//end of class

 
function register_vaincode_social_widget() {
  register_widget('VaincodeSocialWidget');  // Class Name
}
add_action( 'widgets_init', 'register_vaincode_social_widget' );

// **********************************************************************// 
// ! Vaincode WP Color picker for widgets
// **********************************************************************//
function vaincode_widgets_colorpicker_scripts( $hook ) {
    if ( 'widgets.php' != $hook ) {
        return;
    }
    wp_enqueue_style( 'wp-color-picker' );        
    wp_enqueue_script( 'wp-color-picker' ); 
}
add_action( 'admin_enqueue_scripts', 'vaincode_widgets_colorpicker_scripts' );