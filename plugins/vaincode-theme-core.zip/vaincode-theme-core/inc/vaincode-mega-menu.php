<?php
/********************************************
Mega menu post type
********************************************/
 
function vaincode_mega_menu() {

    $labels = array(
        'name'                => _x( 'Mega Menu', 'Post Type General Name', 'vaincode-theme-core' ),
        'singular_name'       => _x( 'Mega Menu', 'Post Type Singular Name', 'vaincode-theme-core' ),
        'all_items'           => __( 'All Mega Menu', 'vaincode-theme-core' ),
        'view_item'           => __( 'View Mega Menu', 'vaincode-theme-core' ),
        'add_new_item'        => __( 'Add New Mega Menu', 'vaincode-theme-core' ),
        'add_new'             => __( 'Add New', 'vaincode-theme-core' ),
        'edit_item'           => __( 'Edit Mega Menu', 'vaincode-theme-core' ),
        'update_item'         => __( 'Update Mega Menu', 'vaincode-theme-core' ),
        'search_items'        => __( 'Search Mega Menu', 'vaincode-theme-core' ),
        'not_found'           => __( 'Not Found', 'vaincode-theme-core' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'vaincode-theme-core' ),
    );
     
    $args = array(
        'label'               => __( 'Mega Menu', 'vaincode-theme-core' ),
        'description'         => __( 'Shows Mega Menu', 'vaincode-theme-core' ),
        'labels'              => $labels,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 5,
        'can_export'          => true,
        'has_archive'         => false,
        'exclude_from_search' => true,
        'show_in_rest'        => true,
		'menu_icon'           => 'dashicons-menu',

    );
     
    // Registering Post Type
    register_post_type( 'mega-menu', $args );
 
}

add_action( 'init', 'vaincode_mega_menu', 0 );