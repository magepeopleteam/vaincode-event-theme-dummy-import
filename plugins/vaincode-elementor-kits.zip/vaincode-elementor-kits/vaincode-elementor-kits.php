<?php
/*
Plugin Name: Vaincode Elementor Kits
Plugin URI: https://vaincode.com
Description: Widgets for Elementor
Version: 1.0
Author: Vaincode Team
Author URI: https://vaincode.com
Text Domain: vaincode-elementor-kits
Domain Path: /languages/
*/

define( 'VAINCODE_ELEMENTOR_KITS_VERSION', '1.0' );
define( 'VAINCODE_ELEMENTOR_KITS__FILE__', __FILE__ );
define( 'VAINCODE_ELEMENTOR_KITS_DIR_URL', plugin_dir_url( VAINCODE_ELEMENTOR_KITS__FILE__ ) );
define( 'VAINCODE_ELEMENTOR_KITS_ASSETS', trailingslashit( VAINCODE_ELEMENTOR_KITS_DIR_URL . 'assets' ) );

#-----------------------------------------------------------------
# Load Vaincode Functions
#-----------------------------------------------------------------

require_once 'inc/vaincode-functions.php';

#-----------------------------------------------------------------
# Load Scripts
#-----------------------------------------------------------------

require_once 'inc/vaincode-enqueue.php';

#-----------------------------------------------------------------
# Load Shortcodes
#-----------------------------------------------------------------

require_once 'inc/vaincode-shortcodes.php';

#-----------------------------------------------------------------
# Load Elementor Widgets
#-----------------------------------------------------------------

require_once 'modules/elementor-elements/elementor.php';

#-----------------------------------------------------------------
# Load Vaincode Icons
#-----------------------------------------------------------------

require_once 'inc/vaincode-icons.php';

#-----------------------------------------------------------------
# Load Vaincode Subscribe
#-----------------------------------------------------------------

require_once 'inc/vaincode-class-subscribe.php';