<?php

namespace Vaincode;

class VaincodeElementor {
	
	private static $_instance = null;
	
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		
		return self::$_instance;
	}
	
	
	public function add_widget_categories( $elements_manager ) {
		
		$elements_manager->add_category(
			'vaincode-elements',
			[
				'title' => __( 'Vaincode Elements', 'vaincode-elementor-kits'),
				'icon'  => 'fa fa-plug',
			]
		);
		
	}
	
	private function include_widgets_files() {
		require_once( __DIR__ . '/vaincode-page-header.php' );		
		require_once( __DIR__ . '/vaincode-countdown.php' );		
		require_once( __DIR__ . '/vaincode-round-image.php' );		
		require_once( __DIR__ . '/vaincode-animated-aboutus-section.php' );		
		require_once( __DIR__ . '/vaincode-speaker-box.php' );		
		require_once( __DIR__ . '/vaincode-pricing-table.php' );		
		require_once( __DIR__ . '/vaincode-video-popup.php' );		
		require_once( __DIR__ . '/vaincode-blog-section.php' );		
		require_once( __DIR__ . '/vaincode-newsletter.php' );		
		require_once( __DIR__ . '/vaincode-contact-form.php' );		
	}
	
	public function register_widgets() {
		
		// Its is now safe to include Widgets files
		$this->include_widgets_files();
		
		// Register Widgets		
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\VaincodePageHeaderWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\VaincodeCountdownWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\VaincodeRoundImageWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\VaincodeAnimatedAboutSecWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\VaincodeSpeakerBoxWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\VaincodePricingTableWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\VaincodeVideoPopupWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\VaincodeBlogSectionWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\VaincodeNewsletterWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\VaincodeContactFormWidget() );
	}
	
	public function __construct() {
        include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
        if ( \is_plugin_active( 'elementor/elementor.php' ) ) {
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'register_widgets' ] );
		add_action( 'elementor/elements/categories_registered', [ $this, 'add_widget_categories' ] );
        }
	}
}


// Instantiate Plugin Class
VaincodeElementor::instance();
