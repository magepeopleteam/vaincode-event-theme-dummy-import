<?php
namespace Vaincode\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Typography;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class VaincodePageHeaderWidget extends Widget_Base {

	public function get_name() {
		return 'vaincode-page-header-widget';
	}

	public function get_title() {
		return __( 'Vaincode Page Header', 'vaincode-elementor-kits' );
	}

	public function get_icon() {
		return 'eicon-header';
	}

	public function get_categories() {
		return [ 'vaincode-elements' ];
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'vaincode_page_header_settings',
			[
				'label' => __( 'Vaincode Page Header Settings', 'vaincode-elementor-kits' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'vaincode_page_header_bg_image',
			[
				'label' => __( 'Background Image', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::MEDIA,
			]
		);

		$this->add_control(
			'vaincode_page_header_bg_size',
			[
				'label' 		=> __( 'Background Size', 'vaincode-elementor-kits' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> 'cover',				
				'options' 		=> [
					'cover' 		=> __( 'Cover', 'vaincode-elementor-kits' ),
					'contain' 		=> __( 'Contain', 'vaincode-elementor-kits' ),
				],
			]
		);

		$this->add_control(
			'vaincode_page_header_bg_position',
			[
				'label' 		=> __( 'Background Position', 'vaincode-elementor-kits' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> 'center',				
				'options' 		=> [
					'top' 		=> __( 'Top', 'vaincode-elementor-kits' ),
					'center' 		=> __( 'Center', 'vaincode-elementor-kits' ),
					'bottom' 		=> __( 'Bottom', 'vaincode-elementor-kits' ),
					'left' 		=> __( 'Left', 'vaincode-elementor-kits' ),
					'right' 		=> __( 'Right', 'vaincode-elementor-kits' ),
				],
			]
		);

		$this->add_control(
			'vaincode_page_header_bg_repeat',
			[
				'label' 		=> __( 'Background Repeat', 'vaincode-elementor-kits' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> 'no-repeat',				
				'options' 		=> [
					'repeat' 		=> __( 'Repeat', 'vaincode-elementor-kits' ),
					'repeat-x' 		=> __( 'Repeat-x', 'vaincode-elementor-kits' ),
					'repeat-y' 		=> __( 'Repeat-y', 'vaincode-elementor-kits' ),
					'no-repeat' 		=> __( 'No-repeat', 'vaincode-elementor-kits' ),
				],
			]
		);

		$this->add_control(
			'vaincode_page_header_text_color',
			[
				'label' => __( 'Text Color', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .bread-crumb h4, .bread-crumb h4 a, .bread-crumb i' => 'color: {{VALUE}};',
				],
			]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'vaincode_page_header_text_typography',
				'label' => __( 'Text Typography', 'vaincode-elementor-kits' ),
				'scheme' => Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} .bread-crumb h4, .bread-crumb h4 a',
			]
        );

        $this->end_controls_section();
	
	}

	protected function render() {

		$settings = $this->get_settings_for_display();
		$vaincode_page_header_bg_image = $settings['vaincode_page_header_bg_image']['url'] ;
		$vaincode_page_header_bg_size = $settings['vaincode_page_header_bg_size'] ;
		$vaincode_page_header_bg_position = $settings['vaincode_page_header_bg_position'] ;
		$vaincode_page_header_bg_repeat = $settings['vaincode_page_header_bg_repeat'] ;
		if($vaincode_page_header_bg_image || $vaincode_page_header_bg_size || $vaincode_page_header_bg_position || $vaincode_page_header_bg_repeat){
			echo "
			<style>
			.page-top-banner {
			    background-image: url(".$vaincode_page_header_bg_image.");
			    background-size: ".$vaincode_page_header_bg_size.";
			    background-position: ".$vaincode_page_header_bg_position.";
			    background-repeat: ".$vaincode_page_header_bg_repeat.";
			}
			</style>
			";
		}
	?>
	<div class="vaincode-elementor-page-header-widget">
		<?php vaincode_page_header_function(); ?>
	</div>
	<?php
}

}
