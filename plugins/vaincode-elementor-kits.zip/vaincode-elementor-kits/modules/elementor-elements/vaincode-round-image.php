<?php
namespace Vaincode\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Typography;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class VaincodeRoundImageWidget extends Widget_Base {

	public function get_name() {
		return 'vaincode-round-image-widget';
	}

	public function get_title() {
		return __( 'Vaincode Round Image', 'vaincode-elementor-kits' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return [ 'vaincode-elements' ];
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'vaincode_round_image_settings',
			[
				'label' => __( 'Vaincode Round Image Settings', 'vaincode-elementor-kits' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'vaincode_round_image',
			[
				'label' => __( 'Choose Image', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => 'https://vaincode.com/demo-one/wp-content/uploads/sites/2/2021/08/about-img-1.jpg',
				],
			]
		);

		$this->add_control(
			'vaincode_bg_animation_image',
			[
				'label' => __( 'Choose Background Animation Image', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => 'https://vaincode.com/demo-one/wp-content/uploads/sites/2/2021/08/shape-2.png',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'vaincode_round_image_border',
				'label' => __( 'Border', 'vaincode-elementor-kits' ),
				'selector' => '{{WRAPPER}} .vaincode-elementor-round-image-widget img',
			]
		);
	    $this->add_control(
	    	'vaincode_round_image_border_radius',
	    	 [
	    	 	'label' => __('Border Radius', 'vaincode-elementor-kits'), 
	    	 	'type' => Controls_Manager::DIMENSIONS, 
	    	 	'size_units' => ['px', '%'], 
	    	 	'selectors' => [
	    	 		'{{WRAPPER}} img ' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
	    	 	]
	    	]
	    );
        $this->add_group_control(
        	\Elementor\Group_Control_Box_Shadow::get_type(), 
        	[
        		'name' => 'vaincode_round_image_box_shadow', 
        		'selector' => '{{WRAPPER}}  img',
        	]
        );

		$this->add_control(
			'vaincode_round_image_width',
			[
				'label' => __( 'Image Size', 'vaincode-elementor-kits' ),
				'description' => __( 'Example: 100px or 50%', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::TEXT,
				'default' => '400px',
	    	 	'selectors' => [
	    	 		'{{WRAPPER}} img ' => 'width: {{VALUE}}',
	    	 	]
			]
		);

		$this->add_control(
			'vaincode_animated_image_rotatation_start',
			[
				'label' => __( 'Animated image Rotatation Start From Degree', 'vaincode-elementor-kits' ),
				'description' => __( 'Example: 0deg', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::TEXT,
				'default' => '0deg'
			]
		);
		$this->add_control(
			'vaincode_animated_image_rotatation_end',
			[
				'label' => __( 'Animated image Rotatation End To Degree', 'vaincode-elementor-kits' ),
				'description' => __( 'Example: 5deg or -5deg', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::TEXT,
				'default' => '5deg'
			]
		);
        $this->end_controls_section();
	
	}

	protected function render() {

		$settings = $this->get_settings_for_display();
		$vaincode_round_image = $settings['vaincode_round_image']['url'];
		$vaincode_bg_animation_image = $settings['vaincode_bg_animation_image']['url'];
		$vaincode_animated_image_rotatation_start = $settings['vaincode_animated_image_rotatation_start'];
		$vaincode_animated_image_rotatation_end = $settings['vaincode_animated_image_rotatation_end'];

		if($vaincode_bg_animation_image){
			echo "
			<style>
            {{WRAPPER}} .vaincode-elementor-round-image-widget:before{background-image:url(".$vaincode_bg_animation_image.");}
			</style>
			";
		}
		if($vaincode_animated_image_rotatation_start && $vaincode_animated_image_rotatation_end){
			echo "
			<style>
				@keyframes dizzling{
				    0%{
				        -webkit-transform: rotate(".$vaincode_animated_image_rotatation_start.");
				        -moz-transform: rotate(".$vaincode_animated_image_rotatation_start.");
				        -ms-transform: rotate(".$vaincode_animated_image_rotatation_start.");
				        -o-transform: rotate(".$vaincode_animated_image_rotatation_start.");
				        transform: rotate(".$vaincode_animated_image_rotatation_start.");
				    }
				    50%{
				        -webkit-transform: rotate(".$vaincode_animated_image_rotatation_end.");
				        -moz-transform: rotate(".$vaincode_animated_image_rotatation_end.");
				        -ms-transform: rotate(".$vaincode_animated_image_rotatation_end.");
				        -o-transform: rotate(".$vaincode_animated_image_rotatation_end.");
				        transform: rotate(".$vaincode_animated_image_rotatation_end.");
				    }
				    100%{
				        -webkit-transform: rotate(".$vaincode_animated_image_rotatation_start."0);
				        -moz-transform: rotate(".$vaincode_animated_image_rotatation_start.");
				        -ms-transform: rotate(".$vaincode_animated_image_rotatation_start.");
				        -o-transform: rotate(".$vaincode_animated_image_rotatation_start.");
				        transform: rotate(".$vaincode_animated_image_rotatation_start.");
				    }
				}            
			</style>
			";
		}
	?>

	<div class="vaincode-elementor-round-image-widget">
		<img src="<?php echo esc_url($vaincode_round_image); ?>"/>
	</div>
	<?php
}

}
