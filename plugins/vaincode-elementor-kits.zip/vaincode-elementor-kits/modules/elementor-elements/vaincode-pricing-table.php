<?php
namespace Vaincode\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Background;
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class VaincodePricingTableWidget extends Widget_Base {

	public function get_name() {
		return 'vaincode-pricing-table-widget';
	}

	public function get_title() {
		return __( 'Vaincode Pricing Table', 'vaincode-elementor-kits' );
	}

	public function get_icon() {
		return 'eicon-price-table';
	}

	public function get_categories() {
		return [ 'vaincode-elements' ];
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'vaincode_pricing_table_settings',
			[
				'label' => __( 'Vaincode Pricing Table Settings', 'vaincode-elementor-kits' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'vaincode_pricing_table_plan_name',
			[
				'label' => __( 'Plan Name', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter plan name', 'vaincode-elementor-kits' ),
				'default' => __( 'Day Pass', 'vaincode-elementor-kits' ),
			]
		);
		$this->add_control(
			'vaincode_pricing_table_plan_currency',
			[
				'label' => __( 'Plan Currency', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter plan currency', 'vaincode-elementor-kits' ),
				'default' => __( '$', 'vaincode-elementor-kits' ),
			]
		);
		$this->add_control(
			'vaincode_pricing_table_plan_price',
			[
				'label' => __( 'Plan Price', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::NUMBER,
				'placeholder' => __( 'Enter plan price', 'vaincode-elementor-kits' ),
				'default' => __( '35.99', 'vaincode-elementor-kits' ),
			]
		);
		$this->add_control(
			'vaincode_pricing_table_plan_duration',
			[
				'label' => __( 'Plan Duration', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => __( '/ per month', 'vaincode-elementor-kits' ),
				'default' => __( '', 'vaincode-elementor-kits' ),
			]
		);
		$this->add_control(
			'vaincode_pricing_table_plan_enable_features',
			[
				'label' => __( 'Plan Enable Features', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter enable features', 'vaincode-elementor-kits' ),
				'default' => __( 'Conference Tickets,Free Lunch And Coffee,Certificate', 'vaincode-elementor-kits' ),
			]
		);
		$this->add_control(
			'vaincode_pricing_table_plan_disable_features',
			[
				'label' => __( 'Plan Disable Features', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter disable features', 'vaincode-elementor-kits' ),
				'default' => __( 'Easy Access,Free Contacts', 'vaincode-elementor-kits' ),
			]
		);
		$this->add_control(
			'vaincode_pricing_table_plan_btn_name',
			[
				'label' => __( 'Plan Button Label', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter button label', 'vaincode-elementor-kits' ),
				'default' => __( 'Buy Ticket', 'vaincode-elementor-kits' ),
			]
		);
		$this->add_control(
			'vaincode_pricing_table_plan_btn_url',
			[
				'label' => __( 'Plan Button URL', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::URL,
				'placeholder' => __( 'https://', 'vaincode-elementor-kits' ),
				'default' => [
					'url' => '#',
					'is_external' => true,
				],
			]
		);
		$this->add_control(
			'vaincode_pricing_table_plan_card_icon',
			[
				'label' => __( 'Plan Card Icon', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::ICONS,
				'default' => [
					'value' => 'flaticon flaticon-rocket-ship',
					'library' => 'vaincode-icons',
				],
			]
		);
		$this->add_control(
			'vaincode_pricing_table_plan_header_bg_image',
			[
				'label' => __( 'Plan Header Background Image', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => VAINCODE_ELEMENTOR_KITS_ASSETS . 'images/pricing-table-header-bg.jpg',
				],
			]
		);		
		$this->add_control(
			'vaincode_pricing_table_plan_body_bg_image',
			[
				'label' => __( 'Plan Body Background Image', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => VAINCODE_ELEMENTOR_KITS_ASSETS . 'images/pricing-table-body-bg.jpg',
				],
			]
		);														
        $this->end_controls_section();
		$this->start_controls_section(
			'vaincode_pricing_table_style',
			[
				'label' => __( 'Vaincode Pricing Table Style', 'vaincode-elementor-kits' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'vaincode_pricing_table_header_icon_switch',
			[
				'label'   => __( 'On/Off Header Icon', 'vaincode-elementor-kits' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'block',
				'options' => [
					'block'  => 'On',
					'none' => 'Off'
				],
				'selectors' => [
					'{{WRAPPER}} .vaincode-elementor-pricing-table-widget .card-image' => 'display: {{VALUE}};',
				],
			]
		);		
		$this->add_control(
			'vaincode_pricing_table_header_icon_color',
			[
				'label' => __( 'Header Icon Color', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .vaincode-elementor-pricing-table-widget .card-image i' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'vaincode_pricing_table_header_icon_bg_color',
			[
				'label' => __( 'Header Icon Background Color', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .vaincode-elementor-pricing-table-widget .card-image i' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'vaincode_pricing_table_header_icon_border_color',
			[
				'label' => __( 'Header Icon Border Color', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .vaincode-elementor-pricing-table-widget .card-image i' => 'border-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'vaincode_pricing_table_header_icon_size',
			[
				'label' => __( 'Header Icon Size (px)', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .vaincode-elementor-pricing-table-widget .card-image i' => 'font-size: {{VALUE}}px;',
				],
			]
		);
		$this->add_control(
			'vaincode_pricing_table_header_icon_wrapper_width',
			[
				'label' => __( 'Header Icon Wrapper Width (px)', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .vaincode-elementor-pricing-table-widget .card-image i' => 'width: {{VALUE}}px;height: {{VALUE}}px;line-height:{{VALUE}}px',
				],
			]
		);			
		$this->add_control(
			'divider1',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'vaincode_pricing_table_plan_name_color',
			[
				'label' => __( 'Plan Label Color', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .vaincode-elementor-pricing-table-widget .plan-name' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'vaincode_pricing_table_plan_name_typography',
				'label' => __( 'Plan Label Typography', 'vaincode-elementor-kits' ),
				'scheme' => Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} .vaincode-elementor-pricing-table-widget .plan-name',
			]
        );
		$this->add_control(
			'divider2',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'vaincode_pricing_table_plan_currency_color',
			[
				'label' => __( 'Plan Currency Color', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .vaincode-elementor-pricing-table-widget .plan-price .curency' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'vaincode_pricing_table_plan_currency_typography',
				'label' => __( 'Plan Currency Typography', 'vaincode-elementor-kits' ),
				'scheme' => Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} .vaincode-elementor-pricing-table-widget .plan-price .curency',
			]
        );
		$this->add_control(
			'divider3',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'vaincode_pricing_table_plan_price_color',
			[
				'label' => __( 'Plan Price Color', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .vaincode-elementor-pricing-table-widget .plan-price .price-number' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'vaincode_pricing_table_plan_price_typography',
				'label' => __( 'Plan Price Typography', 'vaincode-elementor-kits' ),
				'scheme' => Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} .vaincode-elementor-pricing-table-widget .plan-price .price-number',
			]
        );
		$this->add_control(
			'divider4',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'vaincode_pricing_table_plan_duration_color',
			[
				'label' => __( 'Plan Duration Color', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .vaincode-elementor-pricing-table-widget .plan-price .plan-period' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'vaincode_pricing_table_plan_duration_typography',
				'label' => __( 'Plan Duration Typography', 'vaincode-elementor-kits' ),
				'scheme' => Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} .vaincode-elementor-pricing-table-widget .plan-price .plan-period',
			]
        );
		$this->add_control(
			'divider5',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'vaincode_pricing_table_plan_enable_features_icon_color',
			[
				'label' => __( 'Plan Enable Features Icon Color', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .vaincode-elementor-pricing-table-widget ul li.true:before' => 'color: {{VALUE}};',
				],
			]
		);		
		$this->add_control(
			'vaincode_pricing_table_plan_enable_features_color',
			[
				'label' => __( 'Plan Enable Features Text Color', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .vaincode-elementor-pricing-table-widget ul li.true' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'vaincode_pricing_table_plan_enable_features_typography',
				'label' => __( 'Plan Enable Features Text Typography', 'vaincode-elementor-kits' ),
				'scheme' => Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} .vaincode-elementor-pricing-table-widget ul li.true',
			]
        );
		$this->add_control(
			'divider6',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'vaincode_pricing_table_plan_disable_features_icon_color',
			[
				'label' => __( 'Plan Disable Features Icon Color', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .vaincode-elementor-pricing-table-widget ul li.false:before' => 'color: {{VALUE}};',
				],
			]
		);		
		$this->add_control(
			'vaincode_pricing_table_plan_disable_features_color',
			[
				'label' => __( 'Plan Disable Features Text Color', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .vaincode-elementor-pricing-table-widget ul li.false' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'vaincode_pricing_table_plan_disable_features_typography',
				'label' => __( 'Plan Disable Features Text Typography', 'vaincode-elementor-kits' ),
				'scheme' => Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} .vaincode-elementor-pricing-table-widget ul li.false',
			]
        );
		$this->add_control(
			'divider7',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);        
		$this->add_control(
			'vaincode_pricing_table_plan_button_text_color',
			[
				'label' => __( 'Plan Button Text Color', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .vaincode-elementor-pricing-table-widget .button-secondary' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'vaincode_pricing_table_plan_button_bg',
				'label' => __( 'Plan Button Background', 'vaincode-elementor-kits' ),
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .vaincode-elementor-pricing-table-widget .button-secondary',
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
				],
			]
		);

		$this->add_control(
			'vaincode_pricing_table_plan_button_hover_color',
			[
				'label' => __( 'Plan Button Hover Text Color', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .vaincode-elementor-pricing-table-widget .button-secondary:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'vaincode_pricing_table_plan_button_background_hover',
				'label' => __( 'Plan Button Hover Background', 'vaincode-elementor-kits' ),
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .vaincode-elementor-pricing-table-widget .button-secondary:hover',
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
				],
			]
		);        		        		       		        		        		        								
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'vaincode_pricing_table_plan_button_typography',
				'label' => __( 'Plan Button Typography', 'vaincode-elementor-kits' ),
				'scheme' => Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} .vaincode-elementor-pricing-table-widget .button-secondary',
			]
        );
		$this->add_control(
			'divider8',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'vaincode_pricing_table_plan_header_overlay_color',
			[
				'label' => __( 'Plan Header Overlay Color', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .vaincode-elementor-pricing-table-widget .overlay' => 'background: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'vaincode_pricing_table_plan_body_overlay_color',
			[
				'label' => __( 'Plan Body Overlay Color', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .vaincode-elementor-pricing-table-widget .content-overlay' => 'background: {{VALUE}};',
				],
			]
		);				       						
        $this->end_controls_section();			
	}

	protected function render() {

		$settings = $this->get_settings_for_display();
		$vaincode_pricing_table_plan_name = $settings['vaincode_pricing_table_plan_name'];
		$vaincode_pricing_table_plan_currency = $settings['vaincode_pricing_table_plan_currency'];
		$vaincode_pricing_table_plan_price = $settings['vaincode_pricing_table_plan_price'];
		$vaincode_pricing_table_plan_duration = $settings['vaincode_pricing_table_plan_duration'];
		$vaincode_pricing_table_plan_enable_features = $settings['vaincode_pricing_table_plan_enable_features'];
		$vaincode_pricing_table_plan_disable_features = $settings['vaincode_pricing_table_plan_disable_features'];
		$vaincode_pricing_table_plan_btn_name = $settings['vaincode_pricing_table_plan_btn_name'];
		$vaincode_pricing_table_plan_btn_url = $settings['vaincode_pricing_table_plan_btn_url']['url'];
		$vaincode_pricing_table_plan_card_icon = $settings['vaincode_pricing_table_plan_card_icon']['value'];
		$vaincode_pricing_table_plan_header_bg_image = $settings['vaincode_pricing_table_plan_header_bg_image']['url'];
		$vaincode_pricing_table_plan_body_bg_image = $settings['vaincode_pricing_table_plan_body_bg_image']['url'];
	?>

	<div class="vaincode-elementor-pricing-table-widget">

		<?php echo do_shortcode('[vaincode_pricing_table 
			plan_name="'.$vaincode_pricing_table_plan_name.'" 
			plan_currency="'.$vaincode_pricing_table_plan_currency.'" 
			plan_price="'.$vaincode_pricing_table_plan_price.'" 
			plan_duration="'.$vaincode_pricing_table_plan_duration.'" 
			plan_header_bg_image="'.$vaincode_pricing_table_plan_header_bg_image.'" 
			plan_body_bg_image="'.$vaincode_pricing_table_plan_body_bg_image.'" 
			plan_card_icon="'.$vaincode_pricing_table_plan_card_icon.'" 
			plan_enable_features="'.$vaincode_pricing_table_plan_enable_features.'"
			plan_disable_features="'.$vaincode_pricing_table_plan_disable_features.'"
			plan_btn_name="'.$vaincode_pricing_table_plan_btn_name.'" 
			plan_btn_url="'.$vaincode_pricing_table_plan_btn_url.'"]'
			); 
        ?>
	</div>

	<?php
	}
}
