<?php
namespace Vaincode\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Typography;
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class VaincodeContactFormWidget extends Widget_Base {

	public function get_name() {
		return 'vaincode-contact-form-widget';
	}

	public function get_title() {
		return __( 'Vaincode Contact Form', 'vaincode-elementor-kits' );
	}

	public function get_icon() {
		return 'eicon-form-horizontal';
	}

	public function get_categories() {
		return [ 'vaincode-elements' ];
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'vaincode_contact_form_settings',
			[
				'label' => __( 'Vaincode Contact Form Settings', 'vaincode-elementor-kits' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'vaincode_contact_form_subject',
			[
				'label' => __( 'Form Subject','vaincode-elementor-kits' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => 'New Entry: Contact Us',
			]
		);
		$this->add_control(
			'vaincode_contact_form_recipient_email',
			[
				'label' => __( 'Form Recipient Email','vaincode-elementor-kits' ),
				'type' => Controls_Manager::TEXT,
				'default' => get_option( 'admin_email' ),
			]
		);
		$this->add_control(
			'vaincode_contact_form_btn_label',
			[
				'label' => __( 'Form Button Label','vaincode-elementor-kits' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'Send Message',
			]
		);																			
        $this->end_controls_section();
        
		$this->start_controls_section(
			'vaincode_contact_form_style',
			[
				'label' => __( 'Vaincode Contact Form Style', 'vaincode-elementor-kits' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);				
		$this->add_control(
			'vaincode_contact_form_button_text_color',
			[
				'label' => __( 'Button Text Color', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .vaincode-elementor-contact-form-widget #vek_cf_btn' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'vaincode_contact_form_button_bg',
				'label' => __( 'Button Background', 'vaincode-elementor-kits' ),
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .vaincode-elementor-contact-form-widget #vek_cf_btn',
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
				],
			]
		);

		$this->add_control(
			'vaincode_contact_form_button_hover_color',
			[
				'label' => __( 'Button Hover Text Color', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .vaincode-elementor-contact-form-widget #vek_cf_btn:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'vaincode_contact_form_button_background_hover',
				'label' => __( 'Button Hover Background', 'vaincode-elementor-kits' ),
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .vaincode-elementor-contact-form-widget #vek_cf_btn:hover',
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
				],
			]
		);        		        		       		        		        		        								
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'vaincode_contact_form_button_typography',
				'label' => __( 'Button Typography', 'vaincode-elementor-kits' ),
				'scheme' => Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} .vaincode-elementor-contact-form-widget #vek_cf_btn',
			]
        );		
        $this->end_controls_section();		                
	}

	protected function render() {

		$settings = $this->get_settings_for_display();
		$vaincode_contact_form_subject = $settings['vaincode_contact_form_subject'];
		$vaincode_contact_form_recipient_email = $settings['vaincode_contact_form_recipient_email'];
		$vaincode_contact_form_btn_label = $settings['vaincode_contact_form_btn_label'];
	?>

	<div class="vaincode-elementor-contact-form-widget">
    <?php echo do_shortcode('[vaincode_contact_form subject="'.$vaincode_contact_form_subject.'" recipient="'.$vaincode_contact_form_recipient_email.'" btn_label="'.$vaincode_contact_form_btn_label.'"]'); ?>
	</div>

	<?php
}

}
