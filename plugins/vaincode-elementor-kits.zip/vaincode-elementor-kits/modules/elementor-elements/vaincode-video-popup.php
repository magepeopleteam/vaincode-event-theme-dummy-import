<?php
namespace Vaincode\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class VaincodeVideoPopupWidget extends Widget_Base {

	public function get_name() {
		return 'vaincode-video-popup-widget';
	}

	public function get_title() {
		return __( 'Vaincode Video Popup', 'vaincode-elementor-kits' );
	}

	public function get_icon() {
		return 'eicon-play';
	}

	public function get_categories() {
		return [ 'vaincode-elements' ];
	}

	protected function _register_controls() {

/******************************************************************
Vaincode Video Popup Settings
*******************************************************************/

		$this->start_controls_section(
			'vaincode_video_popup_settings',
			[
				'label' => __( 'Vaincode Video Popup Settings', 'vaincode-elementor-kits' ),
			]
		);
		$this->add_control(
			'vaincode_video_popup_type',
			[
				'label' 		=> __( 'Choose Video Type', 'vaincode-elementor-kits' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> 'youtube',				
				'options' 		=> [
					'youtube' 	=> __( 'Youtube', 'vaincode-elementor-kits' ),
					'vimeo' 	=> __( 'Vimeo', 'vaincode-elementor-kits' ),
				],
			]
		);
		$this->add_control(
			'vaincode_video_popup_youtube_id',
			[
				'label' 		=> __( 'Youtube Video ID', 'vaincode-elementor-kits' ),
				'type' 			=> Controls_Manager::TEXT,
				'placeholder' 	=> __( 'aqz-KE-bpKQ', 'vaincode-elementor-kits' ),
				'default' 		=> __( 'aqz-KE-bpKQ', 'vaincode-elementor-kits' ),
				'condition' 	=> ['vaincode_video_popup_type' => 'youtube'],
			]
		);
		$this->add_control(
			'vaincode_video_popup_vimeo_id',
			[
				'label' 		=> __( 'Vimeo Video ID', 'vaincode-elementor-kits' ),
				'type' 			=> Controls_Manager::TEXT,
				'placeholder' 	=> __( '588496072', 'vaincode-elementor-kits' ),
				'default' 		=> __( '588496072', 'vaincode-elementor-kits' ),
				'condition' 	=> ['vaincode_video_popup_type' => 'vimeo'],
			]
		);
		$this->add_control(
			'vaincode_video_popup_icon',
			[
				'label' 		=> __( 'Choose Icon', 'vaincode-elementor-kits' ),
				'type' 			=> Controls_Manager::ICONS,
				'default' 		=> [
					'value' 	=> 'flaticon flaticon-play-button-3',
					'library' 	=> 'vaincode-icons',
				],
			]
		);															
        $this->end_controls_section();

		$this->start_controls_section(
			'vaincode_video_popup_style',
			[
				'label' => __( 'Vaincode Video Popup Style', 'vaincode-elementor-kits' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'vaincode_video_popup_icon_color',
			[
				'label' => __( 'Icon Color', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .vaincode-elementor-video-popup-widget i' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'vaincode_video_popup_icon_bg',
			[
				'label' => __( 'Icon Background', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .vaincode-elementor-video-popup-widget i' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'vaincode_video_popup_icon_font_size',
			[
				'label' => __( 'Icon Font Size', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .vaincode-elementor-video-popup-widget i' => 'font-size: {{VALUE}}px;',
				],
			]
		);
		$this->add_responsive_control(
			'vaincode_video_popup_icon_width',
			[
				'label' => __( 'Icon Width (px)', 'vaincode-elementor-kits' ),
				'type' => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .vaincode-elementor-video-popup-widget i' => 'width: {{VALUE}}px;height: {{VALUE}}px;line-height: {{VALUE}}px',
					'.vaincode-elementor-video-popup-widget .link-lightbox .ripple' => 'width: {{VALUE}}px;height: {{VALUE}}px',
					'.vaincode-elementor-video-popup-widget .link-lightbox .ripple:before' => 'width: {{VALUE}}px;height: {{VALUE}}px',
					'.vaincode-elementor-video-popup-widget .link-lightbox .ripple:after' => 'width: {{VALUE}}px;height: {{VALUE}}px',
				],
			]
		);												
        $this->end_controls_section();		        
	}

	protected function render() {

		$settings = $this->get_settings_for_display();
		$vaincode_video_popup_type = $settings['vaincode_video_popup_type'];
		$vaincode_video_popup_youtube_id = $settings['vaincode_video_popup_youtube_id'];
		$vaincode_video_popup_vimeo_id = $settings['vaincode_video_popup_vimeo_id'];
		$vaincode_video_popup_icon = $settings['vaincode_video_popup_icon']['value'];
	?>

	<div class="vaincode-elementor-video-popup-widget">
	<?php if($vaincode_video_popup_type == 'youtube') { ?>

		<a href="#" class="link-lightbox" data-videoid="<?php echo esc_attr($vaincode_video_popup_youtube_id); ?>" data-videosite="youtube"><i class="<?php echo $vaincode_video_popup_icon; ?>"></i><span class="ripple"></span></a>

	<?php } else { ?>

		<a href="#" class="link-lightbox" data-videoid="<?php echo esc_attr($vaincode_video_popup_vimeo_id); ?>" data-videosite="vimeo"><i class="<?php echo $vaincode_video_popup_icon; ?>"></i><span class="ripple"></span></a>

	<?php } ?>
	</div>

	<?php
}

}
