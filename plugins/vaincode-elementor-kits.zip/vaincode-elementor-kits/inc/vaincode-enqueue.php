<?php

/*****************************************************
Enqueue scripts
******************************************************/

function vaincode_ext_enqueue(){
	wp_enqueue_style('vaincode-elementor-style', VAINCODE_ELEMENTOR_KITS_ASSETS . 'css/style.css?v='.VAINCODE_ELEMENTOR_KITS_VERSION);
	wp_enqueue_style('vaincode-bootstrap-grid', VAINCODE_ELEMENTOR_KITS_ASSETS . 'css/bootstrap-grid.min.css?v='.VAINCODE_ELEMENTOR_KITS_VERSION);	
	wp_enqueue_style('vaincode-lightbox', VAINCODE_ELEMENTOR_KITS_ASSETS . 'css/lightbox.css?v='.VAINCODE_ELEMENTOR_KITS_VERSION);
	wp_enqueue_script('vaincode-custom', VAINCODE_ELEMENTOR_KITS_ASSETS . 'js/vaincode.js?v='.VAINCODE_ELEMENTOR_KITS_VERSION, array('jquery'), '1.0.0', true);
	wp_enqueue_script('vaincode-multi-countdown', VAINCODE_ELEMENTOR_KITS_ASSETS . 'js/multi-countdown.js?v='.VAINCODE_ELEMENTOR_KITS_VERSION, array('jquery'), '1.0.0', true);
	wp_enqueue_script('vaincode-lightbox', VAINCODE_ELEMENTOR_KITS_ASSETS . 'js/lightbox.min.js?v='.VAINCODE_ELEMENTOR_KITS_VERSION, array('jquery'), '1.0.0', true);
}

add_action('wp_enqueue_scripts', 'vaincode_ext_enqueue');
