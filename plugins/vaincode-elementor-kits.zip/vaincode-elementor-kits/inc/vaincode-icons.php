<?php

defined( 'ABSPATH' ) || die();

class Vaincode_Icons_Manager {

    public static function init() {
        add_filter( 'elementor/icons_manager/additional_tabs', [ __CLASS__, 'add_vaincode_icons_tab' ] );
    }

    public static function add_vaincode_icons_tab( $tabs ) {
        $tabs['vaincode-icons'] = [
            'name' => 'vaincode-icons',
            'label' => __( 'Vaincode Flaticons', 'vaincode-elementor-addons' ),
            'url' => VAINCODE_ELEMENTOR_KITS_ASSETS . 'fonts/flaticon/flaticon.css?v='.VAINCODE_ELEMENTOR_KITS_VERSION,
            'enqueue' => [ VAINCODE_ELEMENTOR_KITS_ASSETS . 'fonts/flaticon/flaticon.css?v='.VAINCODE_ELEMENTOR_KITS_VERSION ],
            'prefix' => 'flaticon-',
            'labelIcon' => 'flaticon-setting',
            'ver' => VAINCODE_ELEMENTOR_KITS_VERSION,
            'fetchJson' => VAINCODE_ELEMENTOR_KITS_ASSETS . 'fonts/flaticon/vaincode-flat-icons.js?v=' . VAINCODE_ELEMENTOR_KITS_VERSION,
            'native' => false,
        ];
        return $tabs;
    }
}

Vaincode_Icons_Manager::init();